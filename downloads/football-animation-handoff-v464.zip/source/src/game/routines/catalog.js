import {HIGHLIGHT_CATALOG} from '../config/highlights.default.js';
export const CATALOG={
...Object.fromEntries(HIGHLIGHT_CATALOG.map(d=>['EX_'+d.id,{name:d.name,group:d.group==='defence'?'defence':'attack',highlightGroup:d.group,steps:['C18','C19','C12','N01','A05','N03'].includes(d.id)?2:1}])),
 RF01:{name:'果断攻门—前插抢点与身后接应',group:'attack',steps:1},
 CA01:{name:'直塞边路—传中—门前争顶',group:'attack',steps:3},CA02:{name:'边路接应—横传或倒三角—攻门',group:'attack',steps:3},CA03:{name:'做墙绕人—回做突破',group:'attack',steps:2},CA04:{name:'回接做球—第三人前插',group:'attack',steps:2},CA05:{name:'强侧接应—弱侧转移',group:'attack',steps:2},CA06:{name:'夺球出球—斜插反击',group:'transition',steps:2},
 RA01:{name:'后场三角—向中场递进',group:'build',steps:2},RA02:{name:'中场连接—向前发展',group:'build',steps:2},RA03:{name:'边路推进—前插接应',group:'attack',steps:2},RA04:{name:'中路带动—前插与短接应',group:'build',steps:2},RA05:{name:'受压斜传—向前解压',group:'transition',steps:2},RA06:{name:'门将短开—后场接力',group:'build',steps:2},RA07:{name:'前场输送—就近终结或突破',group:'attack',steps:2},
 RD01:{name:'前迎持球人—身后补位',group:'defence',steps:1},RD02:{name:'边路施压—内侧保护',group:'defence',steps:1},RD03:{name:'封接应区域—保护中路通道',group:'defence',steps:1},RD04:{name:'延缓反击—回收保护身后',group:'defence',steps:1},RD05:{name:'争抢松球—接应与防反保护',group:'transition',steps:1},RD06:{name:'争顶干扰—二点保护',group:'defence',steps:1},RD07:{name:'射门施压—封线与二点保护',group:'defence',steps:1}
};
