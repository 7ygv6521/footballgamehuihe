import {FREQUENCY,isRare} from '../config/highlight-frequency.default.js';
import {HIGHLIGHT_CATALOG} from '../config/highlights.default.js';
import {relationshipTargets} from './relative-geometry.js';
import {ROUTINE_POLICY} from '../config/routines.default.js';
import {finishWindow} from './finishing.js';
import {preferenceMultiplier} from '../coach-influence.js';
import {id,hash} from './snapshot.js';import {CATALOG} from './catalog.js';
import {allowsAttackingPass} from '../pitch-zones.js';
const CW=105/19,CH=68/11,pt=(c,r)=>({x:(c+.5)*CW,y:(r+.5)*CH}),cell=p=>({c:Math.max(0,Math.min(18,Math.floor(p.x/CW))),r:Math.max(0,Math.min(10,Math.floor(p.y/CH)))}),key=p=>{const c=cell(p);return c.c+','+c.r;},snap=p=>{const c=cell(p);return pt(c.c,c.r);},dep=(p,s)=>s===0?p.x:105-p.x,dir=s=>s===0?1:-1,D=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),G=(a,b)=>{const c=cell(a),d=cell(b);return Math.max(Math.abs(c.c-d.c),Math.abs(c.r-d.r));},offset=p=>Math.abs(p.y-34);
export {CW,CH,pt,cell,key,snap,dep,dir,D,G};
const pass=(receiver,target,extra={})=>({type:'pass',mode:'space',receiverId:receiver.id,target:snap(target),loft:false,...extra});
export function rolesFor(g,c,stage=0){
 const actor=g.state.carrier||g.state.pendingAerial?.receiver,side=c.side,s=actor?g.vNextScene(actor):{players:g.teams.flat().map(p=>({id:id(p),side:p.side,keeper:p.num===1,...snap(g.playerPoint(p))}))},players=s.players,ball=snap(actor?g.playerPoint(actor):{x:g.state.ball.tx,y:g.state.ball.ty}),reserved=new Set(players.map(key)),roles=[];
 const mates=players.filter(p=>p.side===side&&!p.keeper&&p.id!==s.actorId);
 const add=(pool,purpose,kind,label,partner=null)=>{
  const options=pool.filter(p=>!roles.some(r=>r.id===p.id)).flatMap(p=>relationshipTargets(s,p,{purpose,ball,partner,reserved,config:g.DECISION_CONFIG}).map(q=>({...q,p}))).sort((a,b)=>b.score-a.score);
  const best=options[0];if(!best)return null;reserved.add(key(best.target));const r={id:best.p.id,kind,purpose:label,target:best.target,options:options.filter(q=>q.p.id===best.p.id).map(q=>q.target),from:{x:best.p.x,y:best.p.y},geometry:{purpose,reference:best.reference,score:best.score}};roles.push(r);return {...best.p,...best.target};
 };
 if(c.template.startsWith('RD')){
  if(c.template==='RD05'){
   const near=mates.slice().sort((a,b)=>D(a,ball)-D(b,ball)),support=add(near.slice(1,5),'outlet','SUPPORT','second-ball-outlet');add(mates,'cover','COVER','protect-after-loose-ball',support);
  }else if(c.template==='RD03'){
   const receiver=players.filter(p=>p.side!==side&&!p.keeper&&p.id!==s.actorId&&D(p,ball)<32).sort((a,b)=>dep(b,1-side)-dep(a,1-side))[0];const mark=receiver&&add(mates,'mark','MARK','close-forward-outlet',receiver);add(mates,'cover','COVER','protect-behind-pressure',mark);
  }else{
   const press=add(mates,'press','APPROACH',c.template==='RD02'?'press-from-inside':'front-pressure');add(mates,'cover','COVER','protect-behind-pressure',press);
  }
 }else{
  const pool=mates.filter(p=>p.id!==c.step?.receiverId),runner=add(pool,c.template==='RA03'?'wing-run':'run','FORWARD_RUN','second-route-forward',players.find(p=>p.id===c.step?.receiverId));
  add(pool,'outlet','SUPPORT','near-short-outlet',runner);
 }
 return roles;
}
export function newCandidates(g){
 const a=g.state.carrier;if(!a||g.state.event||g.state.pendingAerial||g.v415Rules().pending||g.state.v434Preparation)return [];
 const s=g.vNextScene(a),p=s.players.find(p=>p.id===id(a)),side=a.side,ds=dir(side),depth=dep(p,side),mates=s.players.filter(q=>q.side===side&&!q.keeper&&q.id!==p.id),near=mates.filter(q=>D(p,q)>=6&&D(p,q)<=26).sort((a,b)=>D(p,a)-D(p,b)),enemies=s.players.filter(q=>q.side!==side&&!q.keeper),pressure=enemies.some(q=>G(p,q)<=2&&ds*(q.x-p.x)>=-1),forward=mates.filter(q=>dep(q,side)>depth&&D(p,q)<40).sort((a,b)=>D(p,a)-D(p,b)),wide=near.find(q=>offset(q)>=14),support=near[0],out=[];
 const offer=(template,step,members={})=>{if(!step)return;const receiver=s.players.find(q=>q.id===step.receiverId);if(step.type==='pass'&&(!receiver||!allowsAttackingPass(side,p,step.target,{cutback:step.tacticalIntent==='cutback'})))return;const c={template,side,members:{origin:p.id,...members},step,forecast:{preparation:[]}};c.forecast.preparation=rolesFor(g,c).map(r=>({id:r.id,target:r.target,purpose:r.purpose}));out.push(c);};
 if(a.num===1){if(!pressure&&support)offer('RA06',pass(support,support),{support:support.id});return out;}
 if(finishWindow(s).active)return [];const run=relationshipTargets(s,p,{purpose:'run',ball:p,config:g.DECISION_CONFIG})[0];const carry=run?{type:'carry',moveIntent:'dribble',target:run.target}:null;
 if(depth<55&&support)offer('RA01',pass(support,support),{support:support.id});
 if(depth>=30&&depth<=78){const connection=near.find(q=>dep(q,side)>=depth);if(connection)offer('RA02',pass(connection,connection),{support:connection.id});}
 if(offset(p)>=12&&forward.length)offer('RA03',carry,{runner:forward[0].id});
 if(depth>=25&&depth<=85&&offset(p)<=22&&near.length>=2)offer('RA04',carry,{support:support.id});
 if(depth<60&&pressure&&(wide||support))offer('RA05',pass(wide||support,wide||support),{support:(wide||support).id});
 if(depth>=55&&forward[0])offer('RA07',pass(forward[0],{x:forward[0].x+ds*CW,y:forward[0].y},{tacticalIntent:'through-pass'}),{finisher:forward[0].id});
 return out;
}
export function nextAction(g,c,stage){
 const a=g.state.carrier;if(!a)return null;const s=g.vNextScene(a),p=s.players.find(p=>p.id===id(a)),side=a.side,mates=s.players.filter(q=>q.side===side&&!q.keeper&&q.id!==p.id),forward=mates.filter(q=>dep(q,side)>dep(p,side)+CW*.3&&D(p,q)>=6&&D(p,q)<40).sort((a,b)=>D(p,a)-D(p,b));
 if(finishWindow(s).active)return {type:'shoot',target:{x:side?0:105,y:34},terminal:true};
 const receiver=forward.find(q=>q.id===c.members.runner)||forward[0];
 if(receiver)return {...pass(receiver,receiver,{tacticalIntent:dep(receiver,side)>dep(p,side)+CW?'through-pass':undefined}),terminal:true};
 if(a.num===1)return null;const run=relationshipTargets(s,p,{purpose:'run',ball:p,config:g.DECISION_CONFIG})[0];return run?{type:'carry',moveIntent:'dribble',target:run.target,terminal:true}:null;
}
export function defenceCandidates(g){
 if(g.state.event||g.v415Rules().pending||g.state.v434Preparation)return [];const a=g.state.carrier,ball=snap(a?g.playerPoint(a):{x:g.state.ball.tx,y:g.state.ball.ty}),side=a?1-a.side:g.state.nextSide,make=template=>({template,side,members:{},single:true});
 if(g.state.pendingAerial)return [make('RD06')];if(!a)return [make('RD05')];if(a.num===1)return [];
 const defenders=g.teams[side].filter(p=>p.num!==1).map(p=>({id:id(p),...snap(g.playerPoint(p))})),near=defenders.filter(p=>G(p,ball)<=3),out=[];
 if(near.length>=2){out.push(make(offset(ball)>=17?'RD02':'RD01'));if(dep(ball,a.side)>=70)out.push(make('RD07'));out.push(make('RD03'));}
 const s=g.vNextScene(a);if(s.justWonPossession&&near.length>=2)out.push(make('RD04'));return out;
}
// Common routines may finish in this one slot: keep the actor's ordinary choice,
// pre-confirm two complementary supporting duties, and resolve its contest normally.
// Never manufacture an additional pass just to complete a named sequence.
export function ordinaryRoutineCandidates(g,selection){
 const a=g.state.carrier,choice=selection?.selected;if(!a||!choice||g.state.pendingAerial||choice.clearanceKind||selection.behaviourDecision?.forced&&choice.type!=='shoot')return [];
 const s=g.vNextScene(a),p=s.players.find(p=>p.id===id(a)),depth=dep(p,a.side),progress=dir(a.side)*(choice.target.x-p.x),length=D(p,choice.target);
 let template=null;
 if(choice.type==='shoot'&&finishWindow(s).active)template='RF01';
 else if(choice.type==='carry'&&choice.moveIntent!=='protect'&&progress>CW*.4&&depth>=25)template=offset(p)>=12?'RA03':'RA04';
 else if(choice.type==='pass'&&!choice.loft&&length<=26&&progress>CW*.4)template=a.num===1?'RA06':depth<35?'RA01':depth<70?'RA02':'RA07';
 return template?[{template,side:a.side,members:{origin:p.id},step:choice,single:true,ordinaryActorChoice:true,forecast:{preparation:[]}}]:[];
}
export function rank(g,cs,fixture,event,book){return cs.sort((a,b)=>{const score=c=>{const recent=book.filter(q=>q.template===c.template&&q.event>event-24).length,side=c.side,actor=g.state.carrier,scene=actor?g.vNextScene(actor):null,person=scene?.coachResponses?.[Object.values(c.members||{})[0]||g.teams[side].find(p=>p.num!==1)&&id(g.teams[side].find(p=>p.num!==1))],strength=person?.strength||0,style=g.state.coachOrders[side],styleFit=(style==='wing'&&['CA01','CA02','RA03','CA05'].includes(c.template)||style==='possession'&&['RA01','RA02','CA03','CA04'].includes(c.template)||style==='counter'&&['CA06','RA05','RD04'].includes(c.template)||['defend','attack'].includes(style)&&c.template.startsWith('RD'))?1+strength:1,base=c.single?.9:c.template.startsWith('CA')?2:1.3;const actorProfile=scene?.players.find(p=>p.id===scene.actorId),personal=actorProfile&&actorProfile.side===side?preferenceMultiplier(actorProfile.preferences?.[c.step?.type==='carry'?'dribble':'pass']||0,g.DECISION_CONFIG):1;return -Math.log(Math.max(1e-9,hash(fixture.seed,event,c.template,Object.values(c.members||{}).join(','),'priority')))*(1+recent*.5)/(base*styleFit*personal*(c.preferenceWeight||1));};const rarity=c=>{if(!c.exp)return 1;const used=book.filter(q=>q.template===c.template).length;return (isRare(c.exp)?.5:1)*(used===0?.65:1+Math.min(1,used*.12));};const competition=c=>c.exp&&isRare(c.exp)?1/FREQUENCY.rareCompetitionWeight:1;return score(a)*rarity(a)*competition(a)-score(b)*rarity(b)*competition(b);});}
export function probability(g,c){const group=CATALOG[c.template].group,ps=g.teams[c.side].filter(p=>Object.values(c.members||{}).includes(id(p))||c.roles?.some(r=>r.id===id(p))),ability=ps.reduce((s,p)=>s+(group==='defence'?p.pressing:p.passing??5)+(p.awareness??5),0)/Math.max(1,2*ps.length),fam=g.v446Coaching().familiarity[c.side],buff=g.v429Tuning().highlights.coachBuffs[CATALOG[c.template].highlightGroup||(group==='defence'?'defence':'team')][c.side],abilityFactor=Math.max(.6,Math.min(1.4,.9+(ability-5)*.04)),famFactor=.8+fam*.05;
 const base=c.exp?(g.state.highlightMode==='high'?.96:(g.state.simpleDensity??.4)):g.state.routineDensity??(g.state.highlightMode==='high'?ROUTINE_POLICY.highDensity:ROUTINE_POLICY.normalDensity),release=Math.max(0,Math.min(1,ROUTINE_POLICY.releaseRates[c.template]??1));const definition=c.exp&&HIGHLIGHT_CATALOG.find(d=>d.id===c.exp),configured=c.exp&&g.v429Tuning().highlights.events[c.exp],eventFactor=definition?Math.max(0,(configured?.baseProbability??definition.baseProbability)/Math.max(1e-9,definition.baseProbability)):1;if(c.exp){const admissionMultiplier=isRare(c.exp)?FREQUENCY.rareAdmissionMultiplier:1;return {base,eventFactor,admissionMultiplier,ability,abilityFactor,familiarity:fam,familiarityFactor:1+fam*.05,buffPercent:buff,release,probability:g.state.highlightMode==='high'?.96:Math.min(.96,base*admissionMultiplier*eventFactor*abilityFactor*(1+fam*.05)*(1+buff/100)/1.5)};}return {base,ability,abilityFactor,familiarity:fam,familiarityFactor:famFactor,buffPercent:buff,release,probability:Math.min(ROUTINE_POLICY.maximumProbability,base*abilityFactor*famFactor*(1+buff/100))*release};}
