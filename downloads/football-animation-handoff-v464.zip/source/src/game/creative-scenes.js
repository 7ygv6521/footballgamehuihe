import {simpleCandidates,REMOVED} from './simple-entry.js';
import {CREATIVE_SCENES,SCENE_POLICY,ORDINARY_ORGANIZATION_IDS} from './config/creative-scenes.default.js';
import {PITCH_CW as CW,PITCH_CH as CH,PITCH_COLS,PITCH_ROWS} from './config/pitch.default.js';
import {shortestGridPath} from './grid-path.js';
import {buildBallRoute,closestOnRoute,routePoint,routeSummary,crossedRouteCells} from './ball-routes.js';
import {inGridPenaltyArea} from './pitch-zones.js';
const def=new Map(CREATIVE_SCENES.map(d=>[d.id,d])),clone=v=>structuredClone(v),D=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),cell=p=>({col:Math.max(0,Math.min(PITCH_COLS-1,Math.floor(p.x/CW))),row:Math.max(0,Math.min(PITCH_ROWS-1,Math.floor(p.y/CH)))}),key=p=>{const c=cell(p);return c.col+','+c.row;},point=c=>({x:(c.col+.5)*CW,y:(c.row+.5)*CH}),pid=p=>p.side+'-'+p.num,dir=s=>s? -1:1,G=(a,b)=>{const c=cell(a),d=cell(b);return Math.max(Math.abs(c.col-d.col),Math.abs(c.row-d.row));},inside=p=>p.x>=0&&p.x<105&&p.y>=0&&p.y<68;
const basePlan=c=>({positions:Object.fromEntries(c.players.map(p=>[p.id,{...p.to}])),paths:Object.fromEntries(c.players.map(p=>[p.id,clone(p.path)]))});
function row(code,c,plan,people,opponent,detail={},nativeOnly=false){
 const d=def.get(code);if(!d)return null;const side=people[0].side,history=c.history||[],recent=history.slice(-SCENE_POLICY.repeatWindow).flatMap(e=>e.spectacles||e.highlight?.spectacles||[]),same=recent.filter(s=>s.id===code&&s.side===side).length,family=recent.filter(s=>s.family===d.family&&s.side===side).length;
 const pref=people[0].preferences||{},prefKey=d.group==='defence'?'press':d.group==='team'?'pass':'dribble',preferenceFactor=Math.max(.5,Math.min(1.5,1+(pref[prefKey]||0)*.18+(pref.risk||0)*(code==='C01'?.12:.03)));
 const scene={version:SCENE_POLICY.version,id:code,name:d.name,family:d.family,side,scope:d.result,nativeOnly,opponentId:opponent?.id||null,participants:people.map(p=>p.id),reference:{actor:pid(c.event.actor),start:clone(c.event.start),target:clone(c.event.target)},...detail};
 plan.scene=scene;
 const admissionKey=c.event.type==='carry'&&c.event.contact?.challenger?'carry-contact:'+pid(c.event.actor)+':'+pid(c.event.contact.challenger):d.family==='keeper-rescue'?'save:'+pid(c.event.actor):null;
 return {experimentRate:c.simpleRate,admissionBlock:c.admissionBlock,experimentHistory:c.history,definition:d,plan,people,opponent,side,quality:1,cooperative:d.group==='team',scene,nativeOnly,admissionKey,probabilityFactor:preferenceFactor/(1+same*SCENE_POLICY.repeatCost+family*SCENE_POLICY.familyRepeatCost)};
}
function carryPath(c,actor,target,via){
 const blocked=new Set(c.players.filter(p=>p.id!==actor.id).map(p=>key(p.to))),a=shortestGridPath(cell(actor.from),cell(via||target),blocked,actor.budget);if(!a)return null;
 const b=via?shortestGridPath(cell(via),cell(target),blocked,actor.budget-(a.length-1)):[];if(via&&!b)return null;
 const cells=via?[...a,...b.slice(1)]:a;return cells.map((v,i)=>i?point(v):{...actor.from});
}
// New technical variants share one ordinary carry intent and the cached movement allowance.
// Opponents retain their actual confirmed approach/path. Never move a defender aside to make a trick legal.
export function creativeCandidates(c,validate,{nativeLocked=false}={}){return nativeLocked?[]:simpleCandidates(c,validate);}
function oldCreativeCandidates(c,validate,{nativeLocked=false}={}){
 const e=c.event,r=e.result,a=c.players.find(p=>p.id===pid(e.actor));if(!a||a.keeper||c.deadBall||e.v434Preparation||e.rules?.verdict||e.decision?.wholeFlowTerminal&&!nativeLocked)return [];
 const out=[],base=basePlan(c),offer=(code,plan,people,opponent,detail)=>{if(validate(plan,c.players))out.push(row(code,c,plan,people,opponent,detail,nativeLocked));};
 if(e.type==='carry'&&r.moveIntent!=='protect'&&e.contact?.challenger){
  if(nativeLocked&&(r.outcome!=='kept'||c.ownerId!==a.id))return out;
  const d=c.players.find(p=>p.id===pid(e.contact.challenger)),target=nativeLocked?a.to:e.target;if(!d||!d.canTackle||G(a.from,target)<1||!inside(target))return out;
  const path=nativeLocked?a.path:carryPath(c,a,target);if(!path?.length||key(path.at(-1))!==key(target)||path.length-1>a.budget)return out;
  if(nativeLocked&&path.slice(1).some(v=>c.players.some(p=>p.id!==a.id&&key(p.to)===key(v))))return out;
  const vx=target.x-a.from.x,vy=target.y-a.from.y,length=Math.hypot(vx,vy),u={x:vx/length,y:vy/length},projection=(d.from.x-a.from.x)*u.x+(d.from.y-a.from.y)*u.y;
  const contact=clone(e.contact.point),front=projection>=-.5,behind=projection<-.5,shift=Math.abs(u.x*(target.y-a.from.y)-u.y*(target.x-a.from.x));
  const make=()=>({...clone(base),kind:'carry',ownerId:a.id,landing:clone(target),positions:{...clone(base.positions),[a.id]:clone(target)},paths:{...clone(base.paths),[a.id]:clone(path)}});
  const response={playerId:d.id,from:clone(d.from),to:clone(d.to),path:clone(d.path),contact,attempt:'actual-active-tackle',slide:!!r.slide,retainedConfirmedIntent:true};
  const detail={opponentResponse:response,playerPath:clone(path),originalBudget:a.budget,usedSteps:path.length-1,contactRequired:true,terminalOrdinaryOutcome:r.outcome,animation:'dedicated-pose-pending',phases:[]};
  // A rainbow must genuinely clear the defender and land beyond him; even a second defender may invalidate it.
  if(front&&projection>1&&projection<length-1&&path.length-1>=2){
   const ground=buildBallRoute(a.from,target,{apex:0}),hit=closestOnRoute(d.to,ground),t=hit.t,apex=SCENE_POLICY.ballClearance/Math.max(.05,4*t*(1-t));
   if(t>.08&&t<.92&&apex<=SCENE_POLICY.maxApex){
    const route=buildBallRoute(a.from,target,{kind:'creative-overhead',apex,speed:14}),clear=c.players.filter(p=>p.side!==a.side).every(p=>{const h=closestOnRoute(p.to,route);return h.distance>2.8||h.point.z>2.7||h.t<.04||h.t>.96;});
    if(clear){const p=make();p.sceneBallRoute=route;offer('C01',p,[a],d,{...detail,ballRoute:routeSummary(route),clearanceAtOpponent:routePoint(route,t).z,phases:['脚下起球越顶','对手原迎击落空','从侧面绕行','落地重新控球']});}
   }
  }
  // Technical escape needs actual lateral displacement relative to the defender, not just a generic successful run.
  const sideGap=Math.abs(u.x*(target.y-d.from.y)-u.y*(target.x-d.from.x)),sideWays=path.some(p=>Math.abs((p.x-a.from.x)*u.y-(p.y-a.from.y)*u.x)>=CW*.30)||sideGap>CW*.45;
  if(r.slide&&sideWays&&sideGap>2){
   offer('C02',make(),[a],d,{...detail,bodyClearance:{fromPhase:.32,toPhase:.65,height:1.0},phases:['先将球拨离铲截线','跃过实际滑铲','落地追上球'],ballWaypoints:path.map(p=>({...p,z:0}))});
   const p=make(),route=buildBallRoute(a.from,target,{kind:'creative-over-slide',apex:1.05,speed:15});p.sceneBallRoute=route;offer('C03',p,[a],d,{...detail,ballRoute:routeSummary(route),phases:['对手滑铲','挑球越过铲截脚','侧向绕行收球']});
  }
  if(sideWays&&G(d.from,a.from)<=1){
   offer('C04',make(),[a],d,{...detail,phases:['对手伸脚迎击','身体隔球回旋','从侧面带离']});
   // C05 now requires the pre-settled face-to-face route through the defender
   // cell. Ordinary lateral carries must not receive its animation label.
   if(front)offer('C06',make(),[a],d,{...detail,ballWaypoints:[a.from,{x:a.from.x-u.y*.9,y:a.from.y+u.x*.9,z:0},target],phases:['先向一侧引球','扣向另一侧','越过迎击者']});
   if(behind)offer('C08',make(),[a],d,{...detail,phases:['侧后方贴身接触','身体隔住球','转向另一侧出口']});
  }
  const previous=c.history.at(-1),backward=previous?.action==='carry'&&previous.actor===a.name&&((previous.intendedTarget?.x??previous.start.x)-previous.start.x)*vx+((previous.intendedTarget?.y??previous.start.y)-previous.start.y)*vy<0;
  if(sideWays&&backward)offer('C07',make(),[a],d,{...detail,phases:['对手沿原方向追来','急停扣回','反向带离']});
 }
 return out;
}
// Labels for genuinely completed native scenes. This observer changes no positions, outcomes, RNG or success rates.
export function nativeSceneCandidates(c){
 const e=c.event,r=e.result,a=c.players.find(p=>p.id===pid(e.actor)),out=[];if(!a||c.deadBall||e.v434Preparation||e.rules?.verdict&&e.rules.verdict.kind!=='goal')return out;
 const actualOwner=c.ownerId&&c.players.find(p=>p.id===c.ownerId),near=(p,where,gap=1)=>G(p.from,where)<=gap,opponents=c.players.filter(p=>p.side!==a.side),allById=new Map(c.players.map(p=>[p.id,p])),find=p=>p&&(allById.get(p.id||pid(p))),previous=c.history.at(-1),depth=a.side?e.start.x:105-e.start.x;
 const offer=(code,people,opponent,detail={})=>{const p={...basePlan(c),kind:'position'},candidate=row(code,c,p,people,opponent,{verifiedOutcome:r.outcome,positionsUnchanged:true,...detail},true);if(candidate)out.push(candidate);};
 if(e.type==='pass'&&r.outcome==='complete'&&actualOwner?.side===a.side&&!r.clearanceKind){
  const receiver=actualOwner,markers=opponents.filter(p=>!p.keeper&&near(p,receiver.from)&&D(p.to,receiver.to)>CW*1.4),gain=dir(a.side)*(receiver.to.x-receiver.from.x);
  const receiveMove=e.trace?.movements?.find(m=>m.playerId===receiver.id||m.player===receiver.name);
  if(e.motion?.flowReceive&&receiveMove?.recoverySteps>0&&markers.some(p=>D(p.from,receiver.from)<CW*.8)&&G(receiver.from,receiver.to)>=1&&gain>CW*.4&&D(receiver.to,e.start)>8)offer('C10',[receiver,a],markers[0],{receiverFrom:receiver.from,receiverTo:receiver.to,markerFrom:markers[0].from,markerTo:markers[0].to,recoverySteps:receiveMove.recoverySteps,phases:['队友出球','实际接触后顺势带球','摆脱原盯防者']});
  const route=e.ballRoute,straight=buildBallRoute(e.start,e.target),directCells=new Set(crossedRouteCells(straight).map(p=>p.col+','+p.row)),actualCells=route&&new Set(crossedRouteCells(route).map(p=>p.col+','+p.row)),bypassed=route&&opponents.filter(p=>!p.keeper&&directCells.has(key(p.to))&&!actualCells.has(key(p.to)));
  const threatened=bypassed?.filter(p=>closestOnRoute(p.to,straight).distance<3&&closestOnRoute(p.to,route).distance>3.5);
  if(!r.loft&&route&&Math.abs(route.bend)>CW*.5&&threatened?.length&&dir(a.side)*(receiver.to.x-e.start.x)>CW)offer('C11',[a,receiver],threatened[0],{ballRoute:routeSummary(route),bypassedIds:threatened.map(p=>p.id),phases:['直线确实受近处封堵','球以明显弧度绕开','队友接到']});
  if((r.wallPhase==='return'||e.decision?.chainIntent?.template==='CA03'&&e.decision.chainIntent.stage===1)&&previous?.action==='pass'&&previous.result?.outcome==='complete'&&dir(a.side)*(receiver.to.x-previous.start.x)>CW*.7){const d=opponents.find(p=>!p.keeper&&D(p.from,previous.start)<CW*2&&dir(a.side)*(receiver.to.x-p.to.x)>CW*.3);if(d)offer('C12',[a,receiver],d,{sourceEvent:previous.eventId,phases:['首传做墙','原持球者绕过实际防守者','接回向前回做']});}
  const pressure=opponents.find(p=>!p.keeper&&near(p,a.from)&&D(p.to,a.from)<CW*.75&&D(p.from,p.to)>2&&dir(a.side)*(p.from.x-a.from.x)>0);
  if(pressure&&!r.loft&&dir(a.side)*(e.target.x-e.start.x)<-CW*.5&&D(e.start,e.target)<22&&D(receiver.to,pressure.to)>CW*1.5)offer('C09',[a,receiver],pressure,{ballRoute:route?routeSummary(route):null,phases:['正面受压','背身做球','身后队友接到'],animation:'dedicated-pose-pending'});
 if(route&&!r.loft&&Math.abs(route.bend||0)<.1&&r.mode==='space'&&r.tacticalIntent==='through-pass'&&G(receiver.from,receiver.to)>=1&&Math.abs((a.side?0:105)-receiver.to.x)<32){const cells=new Set(crossedRouteCells(route).filter(v=>v.enter>.025&&v.enter<.995).map(v=>v.col+','+v.row));const beaten=opponents.filter(p=>!p.keeper&&cells.has(key(p.to))&&dir(a.side)*(p.to.x-e.start.x)>CW*.3&&dir(a.side)*(receiver.to.x-p.to.x)>CW*.3);if(beaten.length)offer('C26',[a,receiver],beaten[0],{ballRoute:routeSummary(route),beatenIds:beaten.map(p=>p.id),phases:['前插者开始跑动','直线地滚球穿过防守者一格','接球者进入危险区域']});}
  if(r.tacticalIntent==='cutback'&&Math.abs(e.start.y-34)>CH*2&&Math.abs(receiver.to.y-34)<CH&&Math.abs((a.side?0:105)-receiver.to.x)<22){const front=opponents.find(p=>!p.keeper&&Math.abs(p.to.y-e.start.y)<CH&&Math.abs(p.to.x-e.start.x)<CW*2),open=!opponents.some(p=>!p.keeper&&G(p.to,receiver.to)<=1);if(front&&open)offer('C13',[a,receiver],front,{phases:['防守保护前点','球回到后插上接应点','开放攻门窗口形成']});}
 }
 if(e.type==='pass'&&r.outcome==='intercept'&&r.intercepter&&!r.clearanceKind&&dir(a.side)*(e.target.x-e.start.x)>CW&&Math.abs((a.side?0:105)-e.target.x)<32){const d=find(r.intercepter),route=e.ballRoute;if(d&&route&&G(d.from,d.to)>=1){const cells=new Set(crossedRouteCells(route).map(p=>p.col+','+p.row));if(!cells.has(key(d.from))&&cells.has(key(d.to)))offer('C24',[d],a,{defenderPath:d.path,ballRoute:routeSummary(route),phases:['对方尝试向前穿透','防守者从球路外切入','在实际经过格抢先截球']});}}
 if(e.type==='carry'&&r.contactOccurred&&['tackled','loose'].includes(r.outcome)){
  const d=find(e.contact?.challenger),actorFrom=a.from;if(d&&d.side!==a.side&&D(d.from,d.to)>CW*.7&&dir(a.side)*(d.from.x-actorFrom.x)<0&&depth<38&&(actualOwner?.side===d.side||r.outcome==='loose'))offer('C14',[d],a,{opponentResponse:{playerId:a.id,path:a.path},defenderPath:d.path,phases:['进攻者已越过防线','防守者从后追到','实际断球或破坏']});
  if(d&&previous?.action==='carry'&&previous.actor===a.name&&previous.result.contactOccurred&&previous.result.outcome==='kept'&&previous.dribbleEncounter?.selected!==d.name&&(actualOwner?.side===d.side||r.outcome==='loose'))offer('C22',[d],a,{sourceEvent:previous.eventId,firstDefender:previous.dribbleEncounter?.selected,defenderPath:d.path,phases:['第一名防守者刚被摆脱','另一人接力封住出口','实际夺球或破坏']});
 }
 if(e.type==='shoot'){
  const aerial=r.aerialAttempt,point=r.aerial?.contactPoint||e.result.impactPoint||e.target,contenders=opponents.filter(p=>!p.keeper&&G(p.to,point)<=1);
  if(r.aerial?.mode==='header'&&aerial?.actualShot&&aerial.attackCan!==false&&contenders.length)offer('C18',[a],contenders[0],{contact:point,contenderIds:contenders.map(p=>p.id),phases:['双方争顶','进攻者抢先触球','完成头球攻门']});
  if(r.aerial?.mode==='volley'&&aerial?.actualShot&&aerial.attackCan!==false)offer('C19',[a],contenders[0],{contact:point,phases:['高球到达','迎球直接击球','射门按原结算结果完成']});
  if(r.outcome==='aerial_defended'&&aerial?.winner){const d=c.players.find(p=>p.side!==a.side&&aerial.winner===p.name);if(d)offer('C20',[d],a,{contact:point,phases:['双方起跳争抢','防守者抢先触球','头球解围']});}
  const keeper=opponents.find(p=>p.keeper);
  if(r.outcome==='blocked'&&r.blocker&&keeper){const d=find(r.blocker),hit=r.impactPoint||r.landing;if(d&&Math.abs(hit.x-(a.side?0:105))<=CW*1.3&&dir(a.side)*(hit.x-keeper.to.x)>0)offer('C15',[d],a,{impact:hit,keeper:keeper.to,phases:['球路已经越过门将','防守者赶到门线','实际封堵救险']});}
  if(r.outcome==='saved'&&keeper){
   const impact=r.impactPoint||r.controlPoint,move=D(keeper.from,keeper.to),reach=impact?D(keeper.to,impact):Infinity,difficult=move>CH*.7||reach>2.1;
   // Neighbour-grid participation can span metres; do not advertise an impossible arm stretch as a great save.
   if(impact&&difficult&&reach<=3.8&&depth<32)offer('C16',[keeper],a,{keeperFrom:keeper.from,keeperTo:keeper.to,impact,move,reach,phases:['真实射正','门将完成困难移动或伸展','扑出当前射门']});
   const lastFrom=previous?.positionsBefore?.[keeper.side]?.find(p=>p.num===keeper.num),momentum=lastFrom?keeper.from.y-lastFrom.y:0,opposite=impact&&(impact.y-keeper.from.y)*momentum<0;if(opposite&&reach<=3.8&&Math.abs(momentum)>.6&&Math.abs(impact.y-keeper.from.y)>.6)offer('C23',[keeper],a,{sourceEvent:previous.eventId,previousFrom:lastFrom,keeperFrom:keeper.from,impact,phases:['门将原向一侧移动','当前射门去向另一侧','反向调整完成扑救']});
   // C17 is now an explicitly rehearsed two-shot sequence, not a label applied
   // only after a second ordinary shot happens to occur.
  }
 }
 return out.filter(q=>!REMOVED.has(q.definition.id));
}
// A spectacle can choreograph the response instead of waiting for unrelated
// ordinary decisions to produce the whole sequence by chance.
export function rehearsedShotCandidates(c,validate){
 const e=c.event,a=c.players.find(p=>p.id===pid(e.actor)),out=[];
 if(e.type!=='shoot'||!a||a.keeper||c.deadBall||e.v434Preparation||e.rules?.verdict||e.result?.restart)return out;
 const base=basePlan(c),opponents=c.players.filter(p=>p.side!==a.side&&!p.keeper);
 const offer=(code,plan,people,opponent,detail)=>{if(validate(plan,c.players))out.push(row(code,c,plan,people,opponent,detail));};
 const challenger=opponents.filter(p=>p.canTackle&&G(p.from,a.from)<=1&&dir(a.side)*(p.from.x-a.from.x)>=-CW*.3).sort((p,q)=>D(p.from,a.from)-D(q.from,a.from))[0];
 if(challenger){
  const plan={...clone(base),kind:'tackle',ownerId:null,landing:clone(challenger.to),defenderId:challenger.id,contactPoint:clone(a.from)};
  plan.controlPlan={...clone(base),kind:'carry',ownerId:challenger.id,landing:clone(challenger.to)};
  plan.stagedSequence={kind:'pre-shot-poke',actorId:a.id,defenderId:challenger.id,shotReleased:false,steps:[{kind:'wind-up',playerId:a.id,at:clone(a.from)},{kind:'poke',playerId:challenger.id,at:clone(a.from)},{kind:'ball-away',from:clone(a.from),to:clone(challenger.to)}]};
  offer('C21',plan,[challenger],a,{choreographed:true,preShotPoke:true,phases:['进攻者准备起脚','防守者抢先伸脚捅球','球离开射门者脚下'],scriptedSequence:clone(plan.stagedSequence)});
 }
 const keeper=c.players.find(p=>p.side!==a.side&&p.keeper&&G(p.from,p.to)<=p.budget);
 const second=keeper&&c.players.filter(p=>p.side===a.side&&!p.keeper&&p.id!==a.id&&inGridPenaltyArea(keeper.side,p.to)).sort((p,q)=>D(p.to,keeper.to)-D(q.to,keeper.to))[0];
 if(keeper&&second&&inGridPenaltyArea(keeper.side,keeper.to)){
  const first=buildBallRoute(a.from,keeper.to,{kind:'rehearsed-first-shot',speed:24,apex:0});
  const rebound=buildBallRoute(keeper.to,second.to,{kind:'rehearsed-rebound',speed:13,apex:1.4});
  const follow=buildBallRoute(second.to,keeper.to,{kind:'rehearsed-follow-shot',speed:24,apex:0});
  if([first,rebound,follow].every(route=>route.table.every(p=>inside(p)))){
   const plan={...clone(base),kind:'save',ownerId:keeper.id,defenderId:keeper.id,landing:clone(keeper.to),impact:clone(keeper.to),route:first,caught:true};
   plan.stagedSequence={kind:'double-save',firstShooterId:a.id,secondShooterId:second.id,keeperId:keeper.id,shots:2,saves:2,steps:[{kind:'shot',playerId:a.id,from:clone(a.from),to:clone(keeper.to),route:routeSummary(first)},{kind:'parry',playerId:keeper.id,from:clone(keeper.to),to:clone(second.to),route:routeSummary(rebound)},{kind:'shot',playerId:second.id,from:clone(second.to),to:clone(keeper.to),route:routeSummary(follow)},{kind:'save-and-hold',playerId:keeper.id,at:clone(keeper.to)}]};
   offer('C17',plan,[keeper,second],a,{choreographed:true,secondShooterId:second.id,phases:['门将扑出第一脚射门','球反弹到禁区内第二名进攻者','立即补射','门将再次扑出并控制'],scriptedSequence:clone(plan.stagedSequence)});
  }
 }
 return out;
}
// Old configuration keys remain readable, but ordinary organisation is no longer a spectacle.
export function meaningfulLegacy(q,c){
 const code=q.definition.id,e=c.event;if(ORDINARY_ORGANIZATION_IDS.includes(code))return false;
 if(code.startsWith('S'))return true;
 if(['A01','A03','A04'].includes(code))return !!e.contact?.challenger&&e.result.moveIntent==='dribble';
 if(code==='A05')return c.history.at(-1)?.result.contactOccurred===true;
 if(['A06','D05'].includes(code)){const p=e.result.aerial?.contactPoint;return !!p&&c.players.some(d=>d.side!==q.people[0].side&&!d.keeper&&G(d.to,p)<=1);}
 if(code==='D03')return D(e.start,{x:e.side?0:105,y:34})<22;
 if(code==='D06')return !e.result.clearanceKind&&q.plan.impact&&Math.abs((e.side?0:105)-e.target.x)<32;
 if(code==='T05')return c.players.some(p=>p.side!==e.side&&!p.keeper&&dir(e.side)*(p.from.x-e.start.x)>0&&dir(e.side)*(e.target.x-p.to.x)>CW&&Math.abs(p.from.y-e.start.y)<CH*2);
 if(['T01','T03','T07','T09'].includes(code))return false; // Native completed-combination observer owns these claims.
 return true;
}
export function sceneDescription(q){
 if(q.scene)return clone(q.scene);const d=q.definition;
 return {version:SCENE_POLICY.version,id:d.id,name:d.name,family:d.manga?'signature':d.group==='defence'?'defensive-contact':d.group==='team'?'combination':'technical-contact',side:q.side,scope:d.result,participants:q.people.map(p=>p.id),opponentId:q.opponent?.id||null,opponentResponse:q.opponent?{playerId:q.opponent.id,from:q.opponent.from,to:q.opponent.to,path:q.opponent.path,retainedConfirmedIntent:true}:null,nativeOnly:false,phases:[d.condition,d.result]};
}
