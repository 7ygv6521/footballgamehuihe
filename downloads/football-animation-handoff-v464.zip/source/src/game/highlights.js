import {FREQUENCY,isRare} from './config/highlight-frequency.default.js';
import {PITCH_COLS,PITCH_ROWS,PITCH_CW,PITCH_CH} from './config/pitch.default.js';
import {HIGHLIGHT_CATALOG,HIGHLIGHT_DEFAULTS} from './config/highlights.default.js';
import {shortestGridPath} from './grid-path.js';
import {buildBallRoute,contactOnRoute,crossedRouteCells,routePoint,routeTimeAtT,ballRouteWithinPitch} from './ball-routes.js';
import {inGridPenaltyArea} from './pitch-zones.js';
import {jointHighlightCandidates} from './joint-highlights.js';
import {JOINT_HIGHLIGHTS} from './config/joint-highlights.default.js';
import {creativeCandidates,meaningfulLegacy,rehearsedShotCandidates} from './creative-scenes.js';
export const hc=p=>({col:Math.max(0,Math.min(PITCH_COLS-1,Math.floor(p.x/PITCH_CW))),row:Math.max(0,Math.min(PITCH_ROWS-1,Math.floor(p.y/(68/PITCH_ROWS))))});
const key=p=>{const c=hc(p);return c.col+','+c.row;},P=c=>({x:(c.col+.5)*PITCH_CW,y:(c.row+.5)*68/PITCH_ROWS}),D=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),G=(a,b)=>Math.max(Math.abs(hc(a).col-hc(b).col),Math.abs(hc(a).row-hc(b).row)),clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const id=p=>p.side+'-'+p.num,inside=p=>p&&p.x>=0&&p.x<105&&p.y>=0&&p.y<68;
const participantName=p=>p.name||((p.side?'对手':'我方')+p.num+'号');
function pathFor(p,target,positions,players,extraBlocked=[]){
 if(!inside(target))return null;const occupied=new Set(players.filter(q=>q.id!==p.id).map(q=>key(positions[q.id])));for(const q of extraBlocked)occupied.add(key(q));
 const path=shortestGridPath(hc(p.from),hc(target),occupied,p.budget);return path?.map((c,i)=>i?P(c):{...p.from})||null;
}
function exchangePath(p,target,via,positions,players){
 const blocked=new Set(players.filter(q=>q.id!==p.id).map(q=>key(positions[q.id]))),a=shortestGridPath(hc(p.from),hc(via),blocked,p.budget);if(!a)return null;
 const b=shortestGridPath(hc(via),hc(target),blocked,p.budget-a.length+1);return b?[...a,...b.slice(1)].map((c,i)=>i?P(c):p.from):null;
}
export function validateHighlightPlan(plan,players){
 if(!plan)return false;const route=plan.route||plan.sceneBallRoute;if(route&&['carry','pass','aerial-pass'].includes(plan.kind)&&!ballRouteWithinPitch(route,plan.aerial?.contactT??1))return false;const seen=new Set();for(const p of players){const q=plan.positions[p.id],path=plan.paths[p.id]||p.path;if(!inside(q)||seen.has(key(q)))return false;seen.add(key(q));if(!path?.length||G(p.from,q)>p.budget||path.length-1>p.budget)return false;for(let i=1;i<path.length;i++)if(G(path[i-1],path[i])>1)return false;if(key(path[0])!==key(p.from)||key(path.at(-1))!==key(q))return false;}return true;
}
// Geometry and prior facts only. No rendering, time budget, RNG or future actions.
export function highlightCandidates(c){
 const {event:e,players,history}=c,r=e.result,side=e.side,dir=side===0?1:-1,actor=players.find(p=>p.id===id(e.actor)),mates=players.filter(p=>p.side===side&&!p.keeper&&p!==actor),opponents=players.filter(p=>p.side!==side),keeper=opponents.find(p=>p.keeper),byId=new Map(players.map(p=>[p.id,p]));
 if(!actor||e.v434Preparation||r.restart&&r.restart.kind!=='direct_free'||e.rules?.verdict&&e.rules.verdict.kind!=='goal'||c.deadBall&&r.restart?.kind!=='direct_free'||e.rules?.offside?.offside===true)return [];
 const base={positions:Object.fromEntries(players.map(p=>[p.id,{...p.to}])),paths:Object.fromEntries(players.map(p=>[p.id,p.path.map(q=>({...q}))]))};if(!validateHighlightPlan(base,players))return [];
 const found=[],prev=history.at(-1),depth=side===0?105-e.start.x:e.start.x,offset=Math.abs(e.start.y-34),target=e.target,receiver=r.receiver&&byId.get(id(r.receiver)),currentOwner=c.ownerId&&byId.get(c.ownerId),tasks=e.trace.confirmedDecisions?.tasks||[],taskFor=p=>tasks.find(t=>t.id===p.id),intentFor=p=>taskFor(p)||e.trace.confirmedDecisions?.coordination?.receiverId===p.id&&{kind:'RECEIVE_SPACE'}||e.responses?.find(q=>q.player&&id(q.player)===p.id&&/RECEIVE|AERIAL|SUPPORT/.test(q.kind)),moved=p=>G(p.from,p.to)>0,forward=p=>dir*(p.to.x-p.from.x)>0;
 const newPlan=(kind,owner=null,landing=null,extra={})=>({...structuredClone(base),kind,ownerId:owner?.id||null,landing:landing?{...landing}:null,...extra});
 const offer=(code,plan,people,opponent=null,quality=null)=>{if(!plan||!validateHighlightPlan(plan,players))return;const d=HIGHLIGHT_CATALOG.find(d=>d.id===code);if(!d)return;const near=players.filter(p=>p.side!==people[0]?.side&&D(p.to,plan.landing||target)<15).length;if(quality==null)quality=d.group==='defence'?clamp(.85+Math.max(0,35-depth)*.012,.6,1.35):d.group==='team'?clamp(1+dir*((plan.landing||target).x-e.start.x)/100-near*.07,.55,1.35):clamp(1.15-depth*.008-offset*.005-near*.04,.45,1.35);found.push({definition:d,plan,people:people.filter(Boolean),opponent,side:people[0]?.side??side,quality,cooperative:d.group==='team'||['D07','D08','D09'].includes(code)});};
 function controlledPlan(kind,p,point){const plan=newPlan(kind,p,point),path=pathFor(p,point,plan.positions,players);if(!path)return null;plan.positions[p.id]=path.at(-1);plan.paths[p.id]=path;plan.landing={...path.at(-1)};return plan;}
 const sameAttack=h=>h&&h.side===side&&!h.rules?.verdict&&h.result?.outcome!=='goal';
 const prevOwner=prev?.actionOutcomeState?.ball?.carrier||prev?.ballStateAfter?.carrier;
 const received=prev?.action==='pass'&&prev.result?.outcome==='complete'&&sameAttack(prev)&&prevOwner===participantName(actor);
 const wallReturn=received&&(prev.result.wallPhase==='return'||prev.highlight?.joint?.wallComplete);
 const followOrigin=c.looseOrigin,followShot=e.type==='shoot'&&!!followOrigin&&followOrigin.side===side&&history.slice(Math.max(0,history.findIndex(h=>h.eventId===followOrigin.sourceEventId)+1)).every(h=>h.action==='scramble'&&!h.rules?.verdict);
 const actualHeader=r.aerial?.mode==='header',actualVolley=r.aerial?.mode==='volley',aerialPoint=r.aerial?.contactPoint;
 const canAerial=!r.aerial||(aerialPoint&&aerialPoint.z>=(actualHeader?1.35:.4)&&aerialPoint.z<=(actualHeader?2.7:1.3)&&G(actor.to,aerialPoint)<=1&&D(actor.to,aerialPoint)<=8.2);
 const shotLegal=e.type==='shoot'&&!actor.keeper&&depth>0&&D(e.start,target)<=e.ranges.shot+.01&&canAerial&&!e.rules?.offside?.players?.some(p=>p.num===actor.num&&p.offside);
 const desiredRoute=e.type==='shoot'?buildBallRoute({...e.start,z:aerialPoint?.z||0},{x:side===0?105:0,y:clamp(target.y,30.6,37.4),z:.8},{kind:'shot',speed:24,bend:e.routeBend||0,apex:0}):e.type==='pass'?buildBallRoute({...e.start,z:r.headerLayoff?(aerialPoint?.z||0):0},{...target,z:r.loft?.85:0},{kind:r.loft?'loft':'ground',speed:22,apex:r.headerLayoff?1.2:r.loft?4.5:0,bend:e.routeBend||0}):null;
 function aerialDelivery(plan){if(!r.loft&&!r.headerLayoff)return plan;const mode=r.aerialMode||'header';if(!['header','volley'].includes(mode))return plan;const samples=[];for(let i=70;i<=98;i++){const t=i/100,point=routePoint(desiredRoute,t);if(point.z<(mode==='header'?1.35:.4)||point.z>(mode==='header'?2.7:1.3)||G(plan.positions[receiver.id],point)>1||D(plan.positions[receiver.id],point)>8.2)continue;samples.push({t,point,distance:D(point,target)});}samples.sort((a,b)=>a.distance-b.distance);if(!samples[0])return plan;const {t,point}=samples[0],fraction=routeTimeAtT(desiredRoute,t);plan.kind='aerial-pass';plan.ownerId=null;plan.landing={...point};plan.aerial={mode,contactPoint:{...point},contactT:t,contactFraction:fraction,handoffFraction:Math.max(0,fraction-.25/desiredRoute.duration),handoffT:t,incomingRoute:desiredRoute,receiver:r.receiver,attackSide:side,sourceEventId:(history.at(-1)?.eventId||0)+1};return plan;}
 const routeHit=(p,height=1.35)=>desiredRoute&&contactOnRoute(p.to,desiredRoute,{reachX:3.85,reachY:4.128,minT:.04,maxT:.995,maxHeight:height});
 const shotBlockers=shotLegal?opponents.filter(p=>!p.keeper).map(p=>({p,hit:routeHit(p)})).filter(x=>x.hit):[];
 const goal=()=>newPlan('goal',null,{x:side===0?105:0,y:clamp(target.y,30.6,37.4),z:.8},{route:desiredRoute});
 if(shotLegal){
  const previousCarry=prev?.action==='carry'&&sameAttack(prev)&&prev.actor===participantName(actor),cutInside=previousCarry&&Math.abs(prev.start.y-34)-offset>=4&&depth<=35;
  if(cutInside)offer('A05',goal(),[actor],keeper);
  if(actualHeader)offer('A06',goal(),[actor],keeper);
  if(actualVolley)offer('A07',goal(),[actor],keeper);
  if(received&&depth<=14&&Math.abs(prev.start.y-34)>=14&&Math.abs(prev.start.y-(prev.intendedTarget?.y??prev.start.y))>=10)offer('A08',goal(),[actor],keeper);
  if(!r.aerial&&keeper&&D(keeper.to,{x:side===0?105:0,y:34})>=7&&depth<=28&&dir*(keeper.to.x-e.start.x)>0)offer('A09',goal(),[actor],keeper);
  if(followShot)offer('A10',goal(),[actor],keeper);
  if(!r.aerial&&depth>=21&&depth<=31.5&&offset<=11.34)offer('S01',goal(),[actor],keeper);
  if(!r.aerial&&depth<=35&&offset<=22.67&&Math.abs(e.routeBend||desiredRoute.bend||0)>.25)offer('S02',goal(),[actor],keeper);
  if(actualVolley&&actor.skills?.includes('S03')&&players.some(p=>p.id!==actor.id&&G(p.to,actor.to)>1))offer('S03',goal(),[actor],keeper);
  if(r.restart?.kind==='direct_free'&&actor.skills?.includes('S10'))offer('S10',goal(),[actor],keeper);
  if(wallReturn)offer('S04',goal(),[actor,byId.get(prev.side+'-'+prev.actorProfile?.number)],keeper);
  for(const {p,hit}of shotBlockers){const landing=P(hc(hit.point)),plan=newPlan('block',null,landing,{defenderId:p.id,impact:hit.point,route:desiredRoute});offer('D03',plan,[p],actor);offer('S07',plan,[p],actor);if(keeper&&dir*(hit.point.x-keeper.to.x)>0&&Math.abs((side===0?105:0)-hit.point.x)<=7)offer('D04',plan,[p],actor);}
  if(keeper&&inGridPenaltyArea(keeper.side,keeper.to)){
   const hit=routeHit(keeper,2.7);if(hit){const bounce=P({col:hc(keeper.to).col+(side===0?-1:1),row:hc(keeper.to).row+(keeper.to.y>=34?-1:1)}),catchPlan=controlledPlan('save',keeper,keeper.to),parryPlan=inside(bounce)?newPlan('save',null,bounce,{defenderId:keeper.id,impact:hit.point,caught:false,route:desiredRoute}):null;
    if(catchPlan)Object.assign(catchPlan,{defenderId:keeper.id,caught:true,impact:hit.point,route:desiredRoute});offer('D10',parryPlan||catchPlan,[keeper],actor);offer('S09',catchPlan,[keeper],actor);
   }
  }
  if(r.aerial&&aerialPoint?.z>=1.35&&aerialPoint.z<=2.7)for(const p of opponents.filter(p=>!p.keeper&&G(p.to,aerialPoint)<=1&&D(p.to,aerialPoint)<8.2)){const landing=P({col:clamp(hc(aerialPoint).col-dir*2,0,PITCH_COLS-1),row:hc(aerialPoint).row});offer('D05',newPlan('header-clear',null,landing,{defenderId:p.id,impact:aerialPoint}),[p],actor);}
 }
 let carryPlan=null,nearDefenders=[];
 if(e.type==='carry'&&!actor.keeper&&r.moveIntent!=='protect'&&G(e.start,target)>0){
  carryPlan=controlledPlan('carry',actor,target);nearDefenders=opponents.filter(p=>!p.keeper&&p.canTackle&&G(p.from,e.start)<=2&&((target.x-e.start.x)*(p.from.x-e.start.x)+(target.y-e.start.y)*(p.from.y-e.start.y))>=-2);
  if(carryPlan&&nearDefenders.length){const defender=nearDefenders[0],shift=Math.abs(target.y-e.start.y),progress=dir*(target.x-e.start.x);
   if(progress>0&&G(e.start,target)>=2)offer('A02',carryPlan,[actor],defender);
   if(shift>=4)offer('A03',carryPlan,[actor],defender);
   if(shift>=4&&(prev?.action==='carry'||G(defender.from,e.start)<=1))offer('A04',carryPlan,[actor],defender);
   const cell=hc(defender.from),routes=[];for(const sign of [-1,1]){const via=P({col:cell.col,row:cell.row+sign});if(!inside(via))continue;const path=exchangePath(actor,target,via,carryPlan.positions,players);if(path)routes.push({sign,path});}
   if(routes.length===2){const split=structuredClone(carryPlan);split.paths[actor.id]=routes[0].path;split.ballPath=routes[1].path;offer('A01',split,[actor],defender);}
  }
 }
 if(e.type==='carry'&&r.moveIntent==='dribble'){
  const contact=e.contact,defender=contact?.challenger&&byId.get(id(contact.challenger)),point=contact?.point;
  if(defender?.canTackle&&point&&G(defender.from,point)<=defender.budget&&G(actor.from,point)<=actor.budget+1){
   const bounce=P({col:clamp(hc(point).col+dir,0,PITCH_COLS-1),row:clamp(hc(point).row+(point.y>=34?-1:1),0,PITCH_ROWS-1)}),plan=newPlan('tackle',null,bounce,{defenderId:defender.id,contactPoint:point});
   plan.controlPlan=controlledPlan('carry',defender,point);const behind=dir*(defender.from.x-actor.from.x)<-.1;
   if(plan.controlPlan){offer('D02',plan,[defender],actor);if(behind){offer('D01',plan,[defender],actor);offer('S08',plan,[defender],actor);}const other=opponents.find(p=>p!==defender&&!p.keeper&&G(p.from,actor.from)<=1&&dir*(defender.from.x-p.from.x)<0);if(other)offer('D07',plan,[defender,other],actor);}
  }
 }
 if(e.type==='pass'&&receiver&&!actor.keeper&&!e.rules?.offside?.players?.some(p=>p.num===receiver.num&&p.offside)&&inside(target)&&D(e.start,target)<=e.ranges.pass+.01){
  let passPlan=controlledPlan('pass',receiver,target);if(passPlan){passPlan.route=desiredRoute;const length=D(e.start,target),progress=dir*(target.x-e.start.x),receiverTask=intentFor(receiver),running=forward(receiver)&&moved(receiver)||!!receiverTask&&dir*(target.x-receiver.from.x)>0,isWall=r.wallPhase==='return'&&received&&prev.actor===participantName(receiver)&&dir*(target.x-(prev.start?.x??target.x))>0;
   if(isWall)offer('T01',passPlan,[actor,receiver]);
   const outer=Math.abs(receiver.from.y-34)>=Math.abs(e.start.y-34),wide=Math.abs(e.start.y-34)>=15;
   if(wide&&outer&&running&&D(receiver.from,e.start)<=25)offer('T02',passPlan,[actor,receiver]);
   if(received&&prev.actor!==participantName(receiver)&&running&&receiverTask)offer('T03',passPlan,[actor,receiver]);
   if(r.tacticalIntent==='through-pass'&&r.mode==='space'&&running&&dir*(target.x-receiver.from.x)>0&&receiverTask)offer('T05',passPlan,[actor,receiver]);
   if(length>=28&&Math.abs(target.y-e.start.y)>=22)offer('T06',passPlan,[actor,receiver]);
   const runners=mates.filter(p=>['BOX_RUN','FORWARD_RUN','SECOND_BALL','SUPPORT'].includes(taskFor(p)?.kind)&&Math.abs((side===0?105:0)-p.to.x)<=28);
   if(r.tacticalIntent==='cross'&&runners.some(p=>p!==receiver&&key(p.to)!==key(receiver.to)))offer('T07',aerialDelivery(structuredClone(passPlan)),[actor,receiver,...runners.slice(0,1)]);
   if(r.headerLayoff&&r.aerial?.mode==='header'&&canAerial)offer('T08',aerialDelivery(structuredClone(passPlan)),[actor,receiver]);
   if(depth<=14&&offset>=11&&progress<0&&progress>=-21&&Math.abs(target.y-34)<offset&&Math.abs((side===0?105:0)-target.x)<=31.5)offer('T09',passPlan,[actor,receiver]);
   if(c.justWon&&progress>7)offer('T10',passPlan,[actor,receiver]);
  }
 }
 if(c.justWon&&carryPlan&&dir*(target.x-e.start.x)>0)offer('T10',carryPlan,[actor]);
 if(e.type==='pass'&&desiredRoute){const cells=crossedRouteCells(desiredRoute);for(const p of opponents.filter(p=>!p.keeper)){const hit=cells.find(q=>q.col===hc(p.to).col&&q.row===hc(p.to).row);if(!hit)continue;const t=(hit.enter+hit.exit)/2,point=routePoint(desiredRoute,t);if(point.z>1.35||r.loft&&t>.12&&t<.82)continue;
  const plan=controlledPlan('intercept',p,p.to);if(plan){Object.assign(plan,{defenderId:p.id,impact:point,route:desiredRoute});offer('D06',plan,[p],actor);}
 }}
 // Off-ball highlights recognise confirmed purposes that really reach legal destinations.
 const attackRuns=mates.filter(p=>moved(p)&&intentFor(p)&&/FORWARD_RUN|SUPPORT|COUNTER|RECEIVE/.test(intentFor(p).kind));let crossing=null;
 for(let i=0;i<attackRuns.length&&!crossing;i++)for(let j=i+1;j<attackRuns.length;j++){const a=attackRuns[i],b=attackRuns[j];if((a.from.y-b.from.y)*(a.to.y-b.to.y)<0&&D(a.from,b.from)<=28&&D(a.to,b.to)>=7){crossing=[a,b];break;}}
 if(crossing&&currentOwner?.side===side&&e.type!=='shoot')offer('T04',newPlan('position'),crossing);
 const defenders=opponents.filter(p=>!p.keeper&&moved(p)&&taskFor(p)),covers=defenders.filter(p=>['COVER','MARK','CUT_LANE','SHAPE'].includes(taskFor(p).kind)&&G(p.to,taskFor(p).target)<=0);
 const goalwardCovers=covers.filter(p=>dir*(p.to.x-e.start.x)>0);
 if(c.justWon&&currentOwner?.side===side&&goalwardCovers.length>=2&&defenders.some(p=>taskFor(p).kind==='APPROACH'&&G(p.to,e.start)<=1))offer('D08',newPlan('position'),goalwardCovers.slice(0,2),actor);
 const previousTasks=prev?.confirmedDecisions?.tasks||[],marks=covers.filter(p=>{const target=byId.get(taskFor(p).markedPlayer);return taskFor(p).kind==='MARK'&&target&&D(p.to,target.to)<=14&&dir*(p.to.x-target.to.x)>=0;});
 const swaps=marks.filter(p=>{const old=previousTasks.find(t=>t.id===p.id);return old?.markedPlayer&&old.markedPlayer!==taskFor(p).markedPlayer&&marks.some(q=>q!==p&&taskFor(q).markedPlayer===old.markedPlayer&&previousTasks.find(t=>t.id===q.id)?.markedPlayer===taskFor(p).markedPlayer);});
 const second=covers.filter(p=>taskFor(p).purpose==='second-ball');if(currentOwner?.side===side&&swaps.length>=2)offer('D09',newPlan('position'),swaps.slice(0,2),actor);else if((e.type==='scramble'||c.looseOrigin)&&second.length>=2&&new Set(second.map(p=>key(taskFor(p).target))).size>=2)offer('D09',newPlan('position'),second.slice(0,2),actor);
 for(const q of found)if(q.definition.id==='T04')q.plan.completedCrossPair=crossing.map(p=>p.id);
 if(e.type==='pass'&&actor.keeper&&receiver&&actor.skills?.includes('S05')){const plan=controlledPlan('pass',receiver,target);if(plan&&desiredRoute&&desiredRoute.length<=actor.passRange){const cells=crossedRouteCells(desiredRoute);if(!opponents.some(d=>cells.some(v=>key(d.to)===v.col+','+v.row&&v.enter>.025&&v.enter<.995&&routePoint(desiredRoute,(v.enter+v.exit)/2).z<=1.35))){plan.route=desiredRoute;plan.receiverId=receiver.id;offer('S05',plan,[actor,receiver]);}}}
 const joint=[],replaced=new Set(['A01']);
 for(const q of found){const recent=history.slice(-JOINT_HIGHLIGHTS.repeatWindowSlots).filter(h=>h.highlight?.selectedId===q.definition.id&&h.highlight.participants?.some(p=>p.id.startsWith(q.side+'-'))).length;q.probabilityFactor=1/(1+recent*JOINT_HIGHLIGHTS.repeatPenalty);}
 const legacy=[...found.filter(q=>!replaced.has(q.definition.id)),...joint].filter(q=>meaningfulLegacy(q,c)),creative=creativeCandidates(c,validateHighlightPlan);
 return [...legacy,...creative,...rehearsedShotCandidates(c,validateHighlightPlan)].map(q=>{q.experimentHistory=c.history;q.experimentRate=c.simpleRate;q.admissionBlock=c.admissionBlock;if(c.event.type==='carry'&&c.event.contact?.challenger)q.admissionKey='carry-contact:'+id(c.event.actor)+':'+id(c.event.contact.challenger);else if(q.plan.kind==='save')q.admissionKey='save:'+id(c.event.actor);return q;});
}
export function drawHighlight(candidates,settings=HIGHLIGHT_DEFAULTS,mode='normal',chemistry=[3,3],roll=.5){
 const history=candidates[0]?.experimentHistory||[],rows=[];
 for(const q of candidates){if(q.admissionBlock?.side===q.side)continue;const rule=settings.events[q.definition.id];if(!settings.enabled||!rule?.enabled||!(rule.baseProbability>0))continue;const count=history.filter(e=>e.spectacles?.some(s=>s.id===q.definition.id)).length;if(count>=6||history.slice(-2).some(e=>e.spectacles?.some(s=>s.id===q.definition.id)))continue;
 const signatures=history.flatMap(e=>e.spectacles||[]).filter(s=>s.id.startsWith('S')).length;if(q.definition.manga&&signatures>=FREQUENCY.maximumMangaPerMatch)continue;
 const configuredMultiplier=rule.baseProbability/Math.max(1e-9,q.definition.baseProbability),competitionMultiplier=isRare(q.definition.id)?FREQUENCY.rareCompetitionWeight:1,base=(q.definition.manga?FREQUENCY.mangaWeight:1)*competitionMultiplier*configuredMultiplier,ability=q.people.reduce((n,p)=>n+(p.ratings?.control||5),0)/q.people.length,weight=base*(.8+ability*.04)*(1+settings.coachBuffs[q.definition.group][q.side]/100)/(1+count*.6);
 rows.push({q,id:q.definition.id,name:q.definition.name,side:q.side,weight});}
 for(const r of rows){const variants=rows.filter(v=>v.id===r.id&&v.side===r.side).length;r.weight/=variants;}
 const total=rows.length?(mode==='high'?.96:(candidates[0]?.experimentRate??.5)):0,sum=rows.reduce((n,r)=>n+r.weight,0);let cursor=0,selected=null;for(const r of rows){r.probability=sum?r.weight/sum*total:0;cursor+=r.probability;if(!selected&&roll<cursor)selected=r.q;}
 return {selected,trace:{version:'isolated-simple-entry',mode,roll,triggerProbability:total,selectedId:selected?.definition.id||null,selectedProbability:rows.find(r=>r.q===selected)?.probability||0,rows:rows.map(({q,...r})=>r),preSettled:true,successRerolled:false}};
}
