// A family is an encounter, not a technique. More variants must not inflate admission.
export const SCENE_POLICY=Object.freeze({version:'v454-contextual-duels',repeatWindow:20,repeatCost:.7,familyRepeatCost:.18,normalFamilyProbability:.22,nativeFamilyProbability:.30,maxPerEvent:2,ballClearance:2.9,maxApex:4.5});
const row=(id,name,family,group,skills,condition,result,baseProbability=.22)=>({id,name,family,group,skills,condition,result,baseProbability,manga:false,contextual:true});
export const CREATIVE_SCENES=[
 row('C01','彩虹过人','front-duel','individual',['control','dribbling'],'正面有可下脚防守者；预演滑铲、过顶球路、绕行及重新控球','挑球越过迎击者，绕行后重新控球'),
 row('C02','跃起躲铲','slide-escape','individual',['control','running'],'邻近有可下脚防守者；预演滑铲，球与人均有合法出口','避过本次滑铲并重新控球'),
 row('C04','回旋护球摆脱','close-duel','individual',['control','dribbling'],'实际近身迎击，侧向绕行能在原额度内完成','护球回旋，从接触另一侧带离'),
 row('C05','双触横拨突破','front-duel','individual',['control','dribbling'],'真实正面下脚，侧向出口成立','横拨避开下脚，进入防守者侧后方'),
 row('C06','牛尾巴变向','front-duel','individual',['dribbling','control'],'正面迎击且球可先向一侧引动再扣回','球连续反向，避开本次迎击'),
 row('C07','急停扣回摆脱','close-duel','individual',['control','dribbling'],'对手已经接近原推进方向，侧后出口合法','先制动再反向带离，保住球权'),
 row('C10','第一脚领球摆脱','receiving-duel','individual',['control','carrying'],'实际传球成功，接球者原位置受压，移动接球后已摆脱该人','迎球第一脚进入空当；不增加一次行动'),
 row('C11','弧线绕过封线','line-breaking','team',['passing','control'],'实际弧线传球成功，直线会穿过对手格而实际球路绕开','绕开真实封线，完成传接'),
 row('C12','撞墙绕人突破','combination','team',['passing','running'],'两段真实传接完成，绕过实际防守者并向前接回','回做越过迎击者，突破者实际接回'),
 row('C17','倒地后二次扑救','keeper-rescue','defence',['goalkeeping','awareness'],'对方射门时禁区内有第二名进攻者；整段扑球、反弹、补射、再扑提前结算','连续扑出两脚射门'),
 row('C18','对抗中抢先冲顶','aerial-duel','individual',['heading','strength'],'实际空中攻门，有合法争顶对手且进攻者先触球','在争顶中完成攻门；射门成败另记'),
 row('C19','凌空迎球攻门','aerial-finish','individual',['shooting','control'],'真实可触球的凌空射门已出脚','完成本次高难度击球；不保证进球'),
 row('C20','空中抢先解围','aerial-defence','defence',['heading','strength'],'真实空中对抗，防守者赢得接触并完成解围','在对手攻门前将球顶走'),
 row('C21','射门前抢先捅球','close-defence','defence',['pressing','awareness'],'对手准备射门，近身防守者可先碰到脚下球','在射门出脚前捅走球'),
 row('C24','抢先切断穿透球','recovery-defence','defence',['pressing','awareness'],'实际拦截危险向前传球，防守者从球路外移动进真实经过格','及时切断即将送到危险接应点的传球'),
 row('C26','穿透防线的直塞','line-breaking','team',['passing','awareness'],'真实地面空间球越过至少两名防守者，跑动接应进入危险区域','穿过防线送到前插者；不保证后续攻门'),
];
// Keep old saved keys readable, but retire generic labels and use actual-scene recognizers instead.
export const ORDINARY_ORGANIZATION_IDS=Object.freeze(['A02','A03','A04','A06','A07','T01','T02','T03','T04','T05','T06','T07','T08','T09','T10','D03','D05','D06','D07','D08','D09','D10']);
