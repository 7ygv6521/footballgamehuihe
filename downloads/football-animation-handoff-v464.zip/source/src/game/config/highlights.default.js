import {CREATIVE_SCENES} from './creative-scenes.default.js';
// Eligibility and settlement live in highlights.js. These values only control draws.
export const HIGHLIGHT_GROUPS={individual:'精彩个人进攻',team:'精彩团队配合',defence:'精彩防守'};
const row=(id,name,group,skills,condition,result,baseProbability=.025)=>({id,name,group,skills,condition,result,baseProbability,manga:id.startsWith('S')});
export const HIGHLIGHT_CATALOG=[
 row('A05','内切后射门','individual',['shooting','control'],'上一动作已内切，当前实际选择射门','完成本次内切攻门，按特殊终结参数计算成败',.012),
 row('D02','滑铲破坏','defence',['pressing','awareness'],'当前存在合法铲球接触及主动抢断额度','铲到球并破坏当前推进',.03),
 row('S05','鹰眼长传','team',['passing','awareness'],'门将控球，前方有合法接应方案','精准传球并由队友控制，不保证后续进球',.004),
...CREATIVE_SCENES,
 row('N01','受压一脚穿线','team',['passing','control'],'受压接应者与下一出球点同时存在','连续出球越过压迫'),
 row('N02','挑传越过上抢者','team',['passing','control'],'前方有人封地面，身后有队友','挑传越过上抢者并接球'),
 row('N03','横拨摆脱后直接起脚','individual',['dribbling','shooting'],'侧向可形成射门空间','横拨后直接攻门，成败原生结算'),
 row('N04','反跑甩盯防接球','individual',['running','control'],'队友受盯，周围有空间','反跑甩开盯防并接球'),
];
export const HIGHLIGHT_DEFAULTS={enabled:true,coachBuffs:{individual:[50,50],team:[50,50],defence:[50,50]},events:Object.fromEntries(HIGHLIGHT_CATALOG.map(d=>[d.id,{enabled:true,baseProbability:d.baseProbability}]))};
export function validateHighlights(input){const x=structuredClone(input??HIGHLIGHT_DEFAULTS);if(typeof x.enabled!=='boolean')throw Error('精彩事件开关无效');for(const key of Object.keys(HIGHLIGHT_GROUPS)){const p=x.coachBuffs?.[key];if(!Array.isArray(p)||p.length!==2||p.some(v=>!Number.isFinite(v)||v<0||v>200))throw Error('精彩教练Buff须为0—200%');}x.events??={};for(const id of Object.keys(x.events))if(!HIGHLIGHT_DEFAULTS.events[id])delete x.events[id];for(const d of HIGHLIGHT_CATALOG){const q=x.events[d.id]??=structuredClone(HIGHLIGHT_DEFAULTS.events[d.id]);if(typeof q.enabled!=='boolean'||!Number.isFinite(q.baseProbability)||q.baseProbability<0||q.baseProbability>1)throw Error('精彩事件概率无效：'+d.name);}return x;}
