// Generate a legal whole-flow candidate from the current field situation.
import {HIGHLIGHT_CATALOG} from './config/highlights.default.js';
import {shortestGridPath} from './grid-path.js';
import {buildBallRoute,routePoint,routeSummary,crossedRouteCells,closestOnRoute,routeTimeAtT,ballRouteWithinPitch} from './ball-routes.js';
import {inGridPenaltyArea,allowsAttackingPass} from './pitch-zones.js';
import {finishWindow} from './routines/finishing.js';
import {earlyLongPassBlockApplies} from './long-pass-block.js';
const CW=105/19,CH=68/11,dir=s=>s? -1:1,pid=p=>p.side+'-'+p.num,cell=p=>({col:Math.max(0,Math.min(18,Math.floor(p.x/CW))),row:Math.max(0,Math.min(10,Math.floor(p.y/CH)))}),P=c=>({x:(c.col+.5)*CW,y:(c.row+.5)*CH}),key=p=>{const c=cell(p);return c.col+','+c.row;},D=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),G=(a,b)=>Math.max(Math.abs(cell(a).col-cell(b).col),Math.abs(cell(a).row-cell(b).row)),inside=p=>p.x>=0&&p.x<105&&p.y>=0&&p.y<68,clone=structuredClone;
export const SIMPLE_IDS=['C01','C02','C04','C05','C06','C07','C10','C11','C12','C18','C19','C24','C26'];
export const REMOVED=new Set(['C03','C08','A09','C09','C14','C15','C22','C23']);
const def=id=>HIGHLIGHT_CATALOG.find(d=>d.id===id),skill=(p,id)=>p.skills?.includes(id),base=c=>({positions:Object.fromEntries(c.players.map(p=>[p.id,{...p.to}])),paths:Object.fromEntries(c.players.map(p=>[p.id,clone(p.path)]))});
function path(p,to,positions,players,via=null){const b=new Set(players.filter(q=>q.id!==p.id).map(q=>key(positions[q.id]))),a=shortestGridPath(cell(p.from),cell(via||to),b,p.budget);if(!a)return null;const tail=via?shortestGridPath(cell(via),cell(to),b,p.budget-a.length+1):[];if(via&&!tail)return null;return (via?[...a,...tail.slice(1)]:a).map((v,i)=>i?P(v):p.from);}
function make(code,c,plan,people,opponent,details={}){const d=def(code),scene={id:code,name:d.name,family:d.family||d.group,side:people[0].side,participants:people.map(p=>p.id),opponentId:opponent?.id||null,scope:d.result,nativeOnly:false,simpleEntry:true,animation:plan.stagedSequence?'scripted-playback':'dedicated-pose-pending',...details};plan.scene=scene;return {experimentRate:c.simpleRate,admissionBlock:c.admissionBlock,experimentHistory:c.history,definition:d,plan,people,opponent,side:people[0].side,quality:1,cooperative:d.group==='team',scene,admissionKey:c.event.type==='carry'?'carry-contact:'+pid(c.event.actor):undefined};}
function record(c,code,status,reason){c.event.trace.simpleEntry??=[];c.event.trace.simpleEntry.push({id:code,status,reason});}
export function simpleCandidates(c,validate){
 const e=c.event,a=c.players.find(p=>p.id===pid(e.actor));if(!a||e.v434Preparation||c.deadBall||e.rules?.verdict&&e.rules.verdict.kind!=='goal')return [];
 const result=[],offer=(code,plan,people,opponent,details)=>{if(!def(code))return;if(!validate(plan,c.players)){record(c,code,'rejected','global-path-or-occupancy');return;}result.push(make(code,c,plan,people,opponent,details));record(c,code,'feasible',null);},opponents=c.players.filter(p=>p.side!==a.side),original=base(c);
 if(e.type==='carry'&&!a.keeper){
  const preparatory=e.decision?.chainIntent?.sceneId;if(preparatory==='C13'){const plan=clone(original),to=e.target;if(!inside(to))return result;plan.positions[a.id]=to;const ap=path(a,to,plan.positions,c.players);if(!ap)return result;plan.paths[a.id]=ap;Object.assign(plan,{kind:'carry',ownerId:a.id,landing:to});offer('C13',plan,[a],e.contact?.challenger&&c.players.find(p=>p.id===pid(e.contact.challenger)),{preparationOnly:true,phases:['边路推进到底线附近','队友准备后插上接应']});return result;}
  const ds=opponents.filter(p=>!p.keeper&&G(p.from,a.from)<=1&&dir(a.side)*(p.from.x-a.from.x)>=-CW*.15).sort((p,q)=>D(p.from,a.from)-D(q.from,a.from));
  const actual=e.contact?.challenger&&ds.find(p=>p.id===pid(e.contact.challenger)),defaultDefender=actual||ds[0];if(!defaultDefender)return result;
  const facingDefender=ds.find(p=>cell(p.from).col===cell(a.from).col+dir(a.side)&&cell(p.from).row===cell(a.from).row);
  const u={x:Math.sign(cell(defaultDefender.from).col-cell(a.from).col),y:Math.sign(cell(defaultDefender.from).row-cell(a.from).row)},perp={x:-u.y,y:u.x},behind={x:defaultDefender.from.x+u.x*CW,y:defaultDefender.from.y+u.y*CH};
  for(const code of (e.decision?.chainIntent?.sceneId?[e.decision.chainIntent.sceneId]:['A01','C01','C02','C04','C05','C06','C07'])){
   const d=code==='C05'?facingDefender:defaultDefender;
   if(!d){record(c,code,'rejected','no-facing-defender');continue;}
   record(c,code,'entry',null);if(!['C01','C02'].includes(code)&&!skill(a,code)){record(c,code,'rejected','missing-skill');continue;}
   if(['C01','C02'].includes(code)&&!d.canTackle){record(c,code,'rejected','defender-active-tackle-used');continue;}
   if(code==='C01'&&dir(a.side)*(d.from.x-a.from.x)<CW*.5){record(c,code,'rejected','no-front-defender');continue;}
   if(code==='C07'&&cell(a.from).col!==cell(d.from).col){record(c,code,'rejected','not-parallel-runners');continue;}
   if(code==='C02'){
    // The defender's slide is part of the precomputed routine. It need not
    // happen independently in the ordinary preflight outcome.
    const to={x:a.from.x+dir(a.side)*CW,y:a.from.y},front={x:to.x+dir(a.side)*CW,y:to.y},dd={x:Math.sign(a.from.x-d.from.x),y:Math.sign(a.from.y-d.from.y)};let ok=false;
    for(const n of [1,2]){const end={x:d.from.x+dd.x*CW*n,y:d.from.y+dd.y*CH*n};if(!inside(to)||!inside(front)||!inside(end)||key(end)===key(to)||key(end)===key(front))continue;const other=c.players.filter(p=>p.id!==a.id&&p.id!==d.id);if(other.some(p=>[key(to),key(front),key(end)].includes(key(p.to))))continue;
     const plan=clone(original);plan.positions[d.id]=end;plan.positions[a.id]=to;const blocked=new Set(other.map(p=>key(p.to))),dp=shortestGridPath(cell(d.from),cell(end),blocked,Math.min(n,d.budget));if(!dp||a.budget<1)continue;plan.paths[d.id]=dp.map((v,i)=>i?P(v):d.from);plan.paths[a.id]=[a.from,to];Object.assign(plan,{kind:'carry',ownerId:a.id,landing:to});plan.stagedSequence={kind:'evade-scripted-slide',actorId:a.id,defenderId:d.id,steps:[{kind:'ball-touch-away',from:a.from,to},{kind:'slide',playerId:d.id,path:plan.paths[d.id]},{kind:'jump',playerId:a.id,from:a.from,to},{kind:'recontrol',playerId:a.id,at:to}]};offer(code,plan,[a],d,{choreographed:true,phases:['球先脱离铲截线','防守者滑行','跃起躲铲','落地继续带球'],opponentResponse:{playerId:d.id,slide:true,path:plan.paths[d.id],scripted:true},scriptedSequence:clone(plan.stagedSequence),finalFront:front});ok=true;break;}
    if(!ok)record(c,code,'rejected','slide-final-placement');continue;
   }
   let targets;
   if(['A01','C01'].includes(code))targets=[behind];
   else if(['A05','N03'].includes(code))targets=[e.target];
   else if(code==='C07')targets=[{x:a.from.x-dir(a.side)*CW,y:a.from.y},{x:a.from.x-dir(a.side)*CW,y:a.from.y+CH},{x:a.from.x-dir(a.side)*CW,y:a.from.y-CH}];
   else if(code==='C05')targets=[{x:d.from.x+dir(a.side)*CW,y:d.from.y}];
   else if(code==='C04')targets=[{x:d.from.x+dir(a.side)*CW,y:d.from.y+CH},{x:d.from.x+dir(a.side)*CW,y:d.from.y-CH}];
   else targets=[{x:a.from.x+dir(a.side)*CW,y:a.from.y+CH},{x:a.from.x+dir(a.side)*CW,y:a.from.y-CH},{x:a.from.x,y:a.from.y+CH},{x:a.from.x,y:a.from.y-CH}];
   let done=false;
   for(const to of targets){if(!inside(to)||c.players.some(p=>p.id!==a.id&&key(p.to)===key(to)))continue;
    if(code==='C04'&&(a.from.x-d.from.x)*(to.x-d.from.x)+(a.from.y-d.from.y)*(to.y-d.from.y)>=0)continue;
    const plan=clone(original);plan.positions[a.id]=to;
    if(code==='C05'||code==='C04'){
     // The marker reacts within the original cell while the carrier turns
     // around them. Keep a real, legal center for the whole performance.
     if(c.players.some(p=>p.id!==a.id&&p.id!==d.id&&key(p.to)===key(d.from)))continue;
     plan.positions[d.id]={...d.from};plan.paths[d.id]=[{...d.from}];
    }
    if(code==='C07'){
     // Side-by-side runners: the marker carries momentum one cell forward
     // while the carrier checks back one cell. Both final cells are solved now.
     const overrun={x:d.from.x+dir(a.side)*CW,y:d.from.y};
     if(!inside(overrun)||c.players.some(p=>p.id!==a.id&&p.id!==d.id&&key(p.to)===key(overrun)))continue;
     const dp=path(d,overrun,plan.positions,c.players);if(!dp)continue;
     plan.positions[d.id]=dp.at(-1);plan.paths[d.id]=dp;
    }
    if(['A01','C01'].includes(code)){
     const routes=[];for(const s of [-1,1]){const via={x:d.from.x+s*perp.x*CW,y:d.from.y+s*perp.y*CH};if(!inside(via))continue;const q=path(a,to,plan.positions,c.players,via);if(q)routes.push(q);}if(!routes.length)continue;plan.paths[a.id]=routes[0];
     const bends=code==='C01'?[0]:[-CW*.75,CW*.75];let route=null;
     let selectedPath=null;for(const ap of routes){const v={x:to.x-a.from.x,y:to.y-a.from.y},body=ap.map(p=>v.x*(p.y-a.from.y)-v.y*(p.x-a.from.x)).sort((a,b)=>Math.abs(b)-Math.abs(a))[0];for(const bend of bends){if(code==='A01'&&(!body||Math.sign(body)===Math.sign(bend)))continue;const q=buildBallRoute(a.from,to,{kind:code==='C01'?'rainbow':'split-ball',bend,apex:code==='C01'?3.4:0,speed:15});if(!ballRouteWithinPitch(q))continue;const cells=crossedRouteCells(q);if(opponents.every(p=>{const h=closestOnRoute(p.to,q);const actual=cells.find(v=>key(p.to)===v.col+','+v.row),initial=cells.find(v=>key(p.from)===v.col+','+v.row),initialHit=closestOnRoute(p.from,q);return (!actual||actual.enter<.05&&key(p.to)===key(a.from)||h.point.z>2.7)&&(!initial||initial.enter<.05&&key(p.from)===key(a.from)||initialHit.point.z>2.7);})){route=q;selectedPath=ap;plan.splitSides={bodySide:Math.sign(body),ballSide:Math.sign(bend)};break;}}if(route)break;}
     if(!route)continue;plan.paths[a.id]=selectedPath;plan.sceneBallRoute=route;plan.ballPath=route.table.filter((_,i)=>i%16===0);
    }else if(code==='C05'){
     // This pre-settled duel passes through the defender's occupied cell while
     // the defender follows the first feint within it. No lateral grid detour.
     if(a.budget<2)continue;
     plan.paths[a.id]=[{...a.from},{...d.from},{...to}];
    }else {const q=path(a,to,plan.positions,c.players);if(!q)continue;plan.paths[a.id]=q;}
    Object.assign(plan,{kind:'carry',ownerId:a.id,landing:to});if(code==='C01')plan.stagedSequence={kind:'rainbow-over-scripted-slide',actorId:a.id,defenderId:d.id,steps:[{kind:'slide',playerId:d.id,at:d.from},{kind:'rainbow',playerId:a.id,route:routeSummary(plan.sceneBallRoute)},{kind:'run-around',playerId:a.id,path:plan.paths[a.id]},{kind:'recontrol',playerId:a.id,at:to}]};if(code==='A01')plan.stagedSequence={kind:'man-ball-split',actorId:a.id,defenderId:d.id,steps:[{kind:'ball-away',route:routeSummary(plan.sceneBallRoute)},{kind:'run-around',playerId:a.id,path:plan.paths[a.id]},{kind:'recontrol',playerId:a.id,at:to}]};offer(code,plan,[a],d,{choreographed:['C01','A01','C04','C05','C07'].includes(code),splitSides:plan.splitSides||null,preparationOnly:['A05','N03'].includes(code),phases:code==='C07'?['并行向前','持球人突然制动','扣回一格摆脱']:code==='C05'?['侧拨诱使防守者跟随','反向触球','穿过防守者身后']:code==='C06'?['同脚外侧拨球','立刻内侧扣回','加速带离']:code==='C04'?['身体护球启动','围绕防守者回旋','带球离开']:code==='A01'?['分球','人绕另一侧','身后汇合']:code==='C01'?['对手出脚滑铲','起球越顶','绕人收球']:['近身迎击','技术摆脱','带离'],opponentResponse:{playerId:d.id,path:['C04','C05','C07'].includes(code)?plan.paths[d.id]:d.path,slide:code==='C01',scripted:['C01','C04','C05','C07'].includes(code),retainedConfirmedIntent:!['C01','C04','C05','C07'].includes(code)},scriptedSequence:plan.stagedSequence?clone(plan.stagedSequence):null});done=true;break;
   }
   if(!done)record(c,code,'rejected','no-legal-relative-path');
  }
 }
 if(e.type==='pass'&&e.result.receiver){
  const b=c.players.find(p=>p.id===pid(e.result.receiver));if(!b)return result;const line=opponents.map(p=>dir(a.side)*p.from.x).sort((a,b)=>b-a)[1]??105;if(dir(a.side)*(b.from.x-52.5)>0&&dir(a.side)*b.from.x>Math.max(dir(a.side)*e.start.x,line)+.01){record(c,e.decision?.chainIntent?.sceneId||'pass','rejected','initial-offside');return result;}
  const special=e.decision?.chainIntent?.sceneId;
  if(special==='C10'){
   record(c,'C10','entry',null);const marker=opponents.find(d=>G(d.from,b.from)<=1);if(!marker)return result;
   for(const dy of [0,1,-1]){const exit={x:b.from.x+dir(a.side)*CW,y:b.from.y+dy*CH};if(!inside(exit)||c.players.some(p=>p.id!==b.id&&key(p.to)===key(exit)))continue;const plan=clone(original);plan.positions[b.id]=exit;const bp=path(b,exit,plan.positions,c.players);if(!bp)continue;plan.paths[b.id]=bp;const route=buildBallRoute(e.start,b.from,{apex:0}),cells=crossedRouteCells(route);if(route.length>a.passRange||opponents.some(d=>cells.some(v=>key(d.to)===v.col+','+v.row&&v.enter>.025&&key(d.to)!==key(b.from))))continue;Object.assign(plan,{kind:'pass',ownerId:b.id,receiverId:b.id,landing:exit,route,receiverTouch:{point:b.from,exit,playerId:b.id,afterRoute:buildBallRoute(b.from,exit,{apex:0,speed:12})}});plan.stagedSequence={kind:'first-touch-escape',passerId:a.id,receiverId:b.id,from:e.start,touch:b.from,exit,steps:[{kind:'pass',playerId:a.id,route:routeSummary(route)},{kind:'first-touch',playerId:b.id,at:b.from},{kind:'escape',playerId:b.id,path:bp}]};offer('C10',plan,[b,a],marker,{choreographed:true,phases:['来球到达脚下','第一脚触球领向空当','接应者带离原盯防点'],firstTouch:{point:b.from,exit,steps:bp.length-1,opponentId:marker.id},scriptedSequence:clone(plan.stagedSequence)});break;}return result;
  }
  const planned=e.decision?.chainIntent?.template?.startsWith('EX_'),requested=e.decision?.chainIntent?.sceneId;
  if(requested&&['C18','C19','C12','C13','C26','A08','N01','N02'].includes(requested)){
   record(c,requested,'entry',null);const plan=clone(original),target=e.target,q=path(b,target,plan.positions,c.players);if(!q){record(c,requested,'rejected','receiver-path');return result;}plan.positions[b.id]=q.at(-1);plan.paths[b.id]=q;
   // A first wall-pass may let the original passer run after release, all within this slot.
   if(requested==='C12'&&e.decision.chainIntent.stage===0){const run=e.decision.chainIntent.runTarget;if(run){const ap=path(a,run,plan.positions,c.players);if(!ap){record(c,requested,'rejected','wall-run-path');return result;}plan.positions[a.id]=ap.at(-1);plan.paths[a.id]=ap;}}
   if(!allowsAttackingPass(a.side,e.start,target,{cutback:e.result.tacticalIntent==='cutback'})){record(c,requested,'rejected','box-backpass');return result;}const mode=e.decision?.chainIntent?.aerialMode,apex=mode==='header'?3.4:mode==='volley'?3.0:e.result.loft?4.5:0;let route=null;
   for(const bend of requested==='C26'||e.result.loft?[0]:[0,-CW*.7,CW*.7]){const candidate=buildBallRoute(e.start,target,{kind:mode||'simple-pass',apex,bend,speed:22});if(candidate.length>a.passRange+.01||!ballRouteWithinPitch(candidate))continue;const cells=crossedRouteCells(candidate),crossers=opponents.filter(p=>cells.some(v=>key(plan.positions[p.id])===v.col+','+v.row&&v.enter>.025&&v.enter<.995&&routePoint(candidate,(v.enter+v.exit)/2).z<=1.35&&!(mode&&v.enter>=.68&&G(plan.positions[p.id],plan.positions[b.id])<=1)));if(crossers.length>(requested==='C26'?1:0)||crossers.some(p=>p.keeper))continue;route=candidate;break;}
   if(!route){record(c,requested,'rejected','actual-pass-route');return result;}
   Object.assign(plan,{kind:'pass',ownerId:b.id,receiverId:b.id,landing:plan.positions[b.id],route});
   if(mode){const options=[];for(let i=70;i<=98;i++){const t=i/100,p=routePoint(route,t);if(p.z<(mode==='header'?1.35:.4)||p.z>(mode==='header'?2.7:1.3)||G(plan.positions[b.id],p)>1||D(plan.positions[b.id],p)>8.2)continue;options.push({t,p});}if(!options.length){record(c,requested,'rejected','aerial-contact-height');return result;}const {t,p}=options.at(-1),fraction=routeTimeAtT(route,t);Object.assign(plan,{kind:'aerial-pass',ownerId:null,landing:p,aerial:{mode,contactPoint:p,contactT:t,contactFraction:fraction,handoffFraction:Math.max(0,fraction-.25/route.duration),handoffT:t,incomingRoute:route,receiver:e.result.receiver,attackSide:a.side,sourceEventId:c.history.length+1}});}
   if(requested==='C13'&&(dir(a.side)*(target.x-e.start.x)>=-CW*.15||Math.abs(target.y-34)>=Math.abs(e.start.y-34))){record(c,requested,'rejected','not-open-cutback');return result;}
   const overhead=requested==='N02'?opponents.find(d=>{const hit=closestOnRoute(d.from,route);return G(d.from,a.from)<=2&&hit.t>.12&&hit.t<.88&&hit.distance<=2.8&&hit.point.z>2.7;}):null;
   const passedDefender=requested==='C26'?opponents.find(d=>crossedRouteCells(route).some(v=>key(plan.positions[d.id])===v.col+','+v.row&&v.enter>.025&&v.enter<.995)):null;
   if(requested==='C26'&&!passedDefender){record(c,requested,'rejected','no-defender-on-straight-route');return result;}
   if(requested==='N02'&&!overhead){record(c,requested,'rejected','no-actual-overhead-bypass');return result;}if(requested==='N01'&&e.decision.chainIntent.stage===1&&!opponents.some(d=>G(d.from,a.from)<=1&&dir(a.side)*(d.from.x-a.from.x)>=-CW*.15&&dir(a.side)*(target.x-d.from.x)>CW*.3)){record(c,requested,'rejected','no-real-pressured-release');return result;}const code=mode?'C11':requested;offer(code,plan,[a,b],overhead||passedDefender,{preparationFor:mode?requested:null,preparationOnly:!!mode||['C12','N01','A08'].includes(requested)&&e.decision.chainIntent.stage===0,phases:requested==='N02'?['防守者迎上','挑球从其头顶越过','队友接到']:requested==='C26'?['队友斜前插','直线球穿过防线','防守者伸脚落空后接球']:['确认传跑','合法输送','准备最后对抗']});return result;
  }
  if(!a.keeper){
   const requested=e.decision?.chainIntent?.sceneId;
   if(requested==='N04'){
    const plan=clone(original),via={x:b.from.x-dir(a.side)*CW,y:b.from.y},bp=inside(via)&&path(b,e.target,plan.positions,c.players,via);
    if(bp){plan.positions[b.id]=bp.at(-1);plan.paths[b.id]=bp;const route=buildBallRoute(e.start,e.target,{apex:0}),cells=crossedRouteCells(route);if(route.length<=a.passRange&&!opponents.some(d=>cells.some(v=>key(d.to)===v.col+','+v.row&&v.enter>.025))){Object.assign(plan,{kind:'pass',ownerId:b.id,receiverId:b.id,landing:bp.at(-1),route});offer('N04',plan,[b,a],opponents.find(d=>G(d.from,b.from)<=1),{phases:['先回接引动','折向前方','接球'],receiverPath:bp});}}return result;
   }
   record(c,'C11','entry',null);const to=e.target,plan=clone(original),bp=path(b,to,plan.positions,c.players);if(bp){plan.positions[b.id]=bp.at(-1);plan.paths[b.id]=bp;const straight=buildBallRoute(e.start,to,{apex:0}),direct=crossedRouteCells(straight),marked=opponents.filter(p=>direct.some(v=>key(p.to)===v.col+','+v.row)&&closestOnRoute(p.to,straight).distance<3);
    if(marked.length)for(const bend of [-8,8,-6,6,-10,10]){const length=D(e.start,to);if(Math.abs(bend)>length*.45)continue;const route=buildBallRoute(e.start,to,{bend,apex:0,kind:'curved-penetration',speed:22});if(route.length>a.passRange+.01||route.length>length*1.5||route.table.some(p=>!inside(p)))continue;const cells=crossedRouteCells(route);if(opponents.some(p=>cells.some(v=>key(p.to)===v.col+','+v.row))||marked.some(p=>closestOnRoute(p.to,route).distance<=3.5))continue;Object.assign(plan,{kind:'pass',ownerId:b.id,receiverId:b.id,landing:bp.at(-1),route});offer('C11',plan,[a,b],marked[0],{phases:['直线受阻','外脚背大弧线绕行','队友接到']});break;}
   }
  }
  if(dir(a.side)*(e.target.x-e.start.x)>CW&&Math.abs((a.side?0:105)-e.target.x)<32&&e.ballRoute){
   record(c,'C24','entry',null);const route=e.ballRoute,cells=crossedRouteCells(route);let done=false;
   for(const d of opponents.filter(p=>!p.keeper)){if(cells.some(v=>key(d.from)===v.col+','+v.row))continue;for(const hit of cells){const t=(hit.enter+hit.exit)/2,impact=routePoint(route,t),to=P(hit);if(impact.z>1.35||G(d.from,to)<1||G(d.from,to)>2||earlyLongPassBlockApplies({type:'pass',side:e.side,winnerSide:d.side,start:e.start,target:e.target,point:impact,phase:'flight',deliveryKind:e.result.deliveryKind,clearanceKind:e.result.clearanceKind}))continue;const plan=clone(original);plan.positions[d.id]=to;const dp=path(d,to,plan.positions,c.players);if(!dp||dp.length-1>2)continue;plan.paths[d.id]=dp;Object.assign(plan,{kind:'intercept',ownerId:d.id,defenderId:d.id,landing:to,impact,route});plan.stagedSequence={kind:'cut-through-pass',passerId:a.id,defenderId:d.id,contactT:t,controlAt:to,steps:[{kind:'pass',playerId:a.id,route:routeSummary(route)},{kind:'cut',playerId:d.id,path:dp},{kind:'intercept',playerId:d.id,at:impact},{kind:'control',playerId:d.id,at:to}]};offer('C24',plan,[d],a,{choreographed:true,phases:['危险向前球','身体碰球拨向一侧','追上弹球并控制'],defenderSteps:dp.length-1,scriptedSequence:clone(plan.stagedSequence)});done=true;break;}if(done)break;}
  }
 }
 return result;
}
export function simpleGuaranteed(c,validate){const ci=c.event.decision?.chainIntent;if(!ci?.template?.startsWith('EX_'))return null;const qs=simpleCandidates(c,validate),wanted=ci.sceneId,q=qs.find(q=>q.definition.id===wanted)||qs.find(q=>q.scene?.preparationFor===wanted);if(!q)return null;const preparation=q.scene.preparationOnly;q.plan.joint={version:'simple-entry-experiment',scope:q.definition.result,participants:q.people.map(p=>p.id),passes:c.event.type==='pass'?[{fromId:pid(c.event.actor),toId:q.plan.receiverId}]:[],steps:Object.fromEntries(q.people.map(p=>[p.id,{used:q.plan.paths[p.id].length-1,budget:p.budget}])),movementOrder:q.people.map(p=>p.id),extraSlots:0,includesShot:false,wallComplete:wanted==='C12'&&ci.stage===1};return {selected:q,trace:{selectedId:q.definition.id,preSettled:true,guaranteedIntermediate:true,simpleEntry:true,preparationOnly:preparation}};}
export function simpleRecipeCandidates(g,selection){
 const a=g.state.carrier;if(!a||g.state.pendingAerial||g.state.event||g.v415Rules().pending||g.state.v434Preparation)return [];
 const s=g.vNextScene(a),p=s.players.find(p=>p.id===pid(a)),mates=s.players.filter(q=>q.side===a.side&&!q.keeper&&q.id!==p.id),enemies=s.players.filter(q=>q.side!==a.side&&!q.keeper),front=enemies.filter(d=>G(p,d)<=1&&dir(a.side)*(d.x-p.x)>=-CW*.15),out=[],skills=a.spectacleSkills||[];
 const offer=(id,step,members={},extra={})=>{const settings=g.v429Tuning().highlights;if(!settings.enabled||!settings.events[id]?.enabled||settings.events[id]?.baseProbability===0)return;const performerId=['C18','C19'].includes(id)?members.finisher:['C10','N04','N01'].includes(id)?members.support:p.id,performer=g.teams.flat().find(q=>pid(q)===performerId),qualified=['C01','C02'].includes(id)||performer?.spectacleSkills?.includes(id)||false;g.state.simpleEntryInputLog??=[];g.state.simpleEntryInputLog.push({event:g.state.actionHistory.length+1,actor:p.id,performer:performerId,id,skill:qualified});if(!qualified)return;const recent=g.state.actionHistory||[],hits=recent.filter(e=>e.spectacles?.some(q=>q.id===id));if(hits.length>=6||recent.slice(-2).some(e=>e.spectacles?.some(q=>q.id===id)))return;out.push({template:'EX_'+id,side:a.side,exp:id,step,preferenceWeight:selection?.selected?.type===step.type?2:.45,members:{origin:p.id,...members},forecast:{preparation:[]},...extra});};
 if(a.num!==1&&!finishWindow(s).active){
  for(const d of front.slice(0,1)){const u={x:Math.sign(cell(d).col-cell(p).col),y:Math.sign(cell(d).row-cell(p).row)},to={x:d.x+u.x*CW,y:d.y+u.y*CH};if(inside(to)&&!s.players.some(q=>q.id!==p.id&&key(q)===key(to)))for(const id of ['A01','C01'])offer(id,{type:'carry',moveIntent:'dribble',target:to},{defender:d.id});
   for(const id of ['C02','C04','C06','C07']){const to=id==='C07'?{x:p.x-dir(a.side)*CW,y:p.y}:{x:p.x+dir(a.side)*CW,y:p.y+(p.y<34?CH:-CH)};if(inside(to))offer(id,{type:'carry',moveIntent:'dribble',target:to},{defender:d.id});}
   const walls=mates.filter(b=>D(p,b)>=6&&D(p,b)<=24).sort((b,c)=>D(p,b)-D(p,c));for(const b of walls.slice(0,2)){const run={x:d.x+dir(a.side)*CW,y:d.y+(p.y<d.y?-CH:CH)};if(inside(run))offer('C12',{type:'pass',receiverId:b.id,target:{x:b.x,y:b.y},mode:'feet'},{support:b.id,defender:d.id},{runTarget:run});}
  }
  const facing=front.find(d=>cell(d).col===cell(p).col+dir(a.side)&&cell(d).row===cell(p).row);
  if(facing){const to={x:facing.x+dir(a.side)*CW,y:facing.y};if(inside(to))offer('C05',{type:'carry',moveIntent:'dribble',target:to},{defender:facing.id});}
  const nearMates=mates.filter(b=>D(p,b)>=6&&D(p,b)<=28).sort((b,c)=>D(p,b)-D(p,c));
  for(const b of nearMates.slice(0,3)){
   offer('C11',{type:'pass',receiverId:b.id,target:{x:b.x,y:b.y},mode:'feet'},{support:b.id});
   if(enemies.some(d=>G(d,b)<=1)){
    offer('C10',{type:'pass',receiverId:b.id,target:{x:b.x,y:b.y},mode:'feet'},{support:b.id});
    const target={x:b.x+dir(a.side)*CW,y:b.y};if(inside(target))offer('N04',{type:'pass',receiverId:b.id,target,mode:'space'},{support:b.id});
    const next=mates.find(v=>v.id!==b.id&&D(b,v)>=6&&D(b,v)<=24&&dir(a.side)*(v.x-b.x)>CW);if(next)offer('N01',{type:'pass',receiverId:b.id,target:{x:b.x,y:b.y},mode:'feet'},{support:b.id,finisher:next.id});
   }
   if(front.length&&dir(a.side)*(b.x-p.x)>CW)offer('N02',{type:'pass',receiverId:b.id,target:{x:b.x,y:b.y},mode:'feet',loft:true},{support:b.id});
   if(dir(a.side)*(b.x-p.x)>CW&&enemies.some(d=>dir(a.side)*(d.x-p.x)>0&&dir(a.side)*(b.x+dir(a.side)*CW-d.x)>0))for(const dy of [0,-CH,CH]){const target={x:b.x+dir(a.side)*CW,y:b.y+dy};if(inside(target))offer('C26',{type:'pass',receiverId:b.id,target,mode:'space',tacticalIntent:'through-pass'},{support:b.id});}
  }
  if(Math.abs(p.y-34)>=12&&Math.abs((a.side?0:105)-p.x)<=CW*4){for(const b of mates.filter(b=>inGridPenaltyArea(1-a.side,b)).slice(0,3)){const bottom={x:a.side?CW*1.5:105-CW*1.5,y:p.y},already=G(p,bottom)===0;for(const dy of [0,-1,1]){const finishTarget={x:b.x,y:b.y+dy*CH};if(!inside(finishTarget)||!inGridPenaltyArea(1-a.side,finishTarget))continue;if(already)offer('C13',{type:'pass',receiverId:b.id,target:finishTarget,mode:'space',tacticalIntent:'cutback'},{finisher:b.id});else offer('C13',{type:'carry',moveIntent:'dribble',target:bottom},{finisher:b.id},{bottom:true,finishTarget});}}}
  if(dir(a.side)*(p.x-52.5)>15&&Math.abs(p.y-34)>CH){const target={x:p.x+dir(a.side)*CW,y:p.y+Math.sign(34-p.y)*CH};if(inside(target))offer('A05',{type:'carry',moveIntent:'dribble',target},{},{finishAfter:true});}
  if(front.length&&Math.abs((a.side?0:105)-p.x)<28){const target={x:p.x,y:p.y+(p.y<34?CH:-CH)};if(inside(target))offer('N03',{type:'carry',moveIntent:'dribble',target},{},{finishAfter:true});}
  if(Math.abs(p.y-34)>12&&Math.abs((a.side?0:105)-p.x)<35)for(const b of mates.filter(b=>Math.abs((a.side?0:105)-b.x)<14&&Math.abs(b.y-34)<CH*1.5).slice(0,2))offer('A08',{type:'pass',receiverId:b.id,target:{x:b.x,y:b.y},mode:'feet'},{finisher:b.id},{finishAfter:true});
  if(!inGridPenaltyArea(1-a.side,p))for(const b of mates.filter(b=>inGridPenaltyArea(1-a.side,b)||(Math.abs((a.side?0:105)-b.x)<=32&&Math.abs(b.y-34)<=CH*3)).sort((b,c)=>D(p,b)-D(p,c)).slice(0,3)){
   for(const target of [{x:b.x+dir(a.side)*CW,y:b.y},{x:b.x+dir(a.side)*CW*2,y:b.y},{x:b.x,y:b.y+Math.sign(34-b.y)*CH},{x:b.x,y:b.y}].filter(t=>inside(t)&&inGridPenaltyArea(1-a.side,t)))for(const id of ['C19','C18'])offer(id,{type:'pass',receiverId:b.id,target,mode:'space',loft:true,aerialMode:id==='C19'?'volley':'header',tacticalIntent:'cross'},{finisher:b.id});
  }
 }
 return out;
}
