import {env} from 'cloudflare:workers';

const SCENES=new Set(['C01','C02','C04','C05','C06','C07','C10','C11','C12','C17','C18','C19','C20','C21','C24','C26','A05','D02','S05','N01','N02','N03','N04']);
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
const boardValid=(value:unknown)=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
async function table(){await env.DB.prepare('CREATE TABLE IF NOT EXISTS animation_review_comments (board_id TEXT NOT NULL, comment_id TEXT NOT NULL PRIMARY KEY, scene_id TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL)').run();}

export async function GET(request:Request){
 const board=new URL(request.url).searchParams.get('board');if(!boardValid(board))return json({error:'留言板编号无效'},400);
 try{await table();const result=await env.DB.prepare('SELECT comment_id AS id,scene_id AS sceneId,body,created_at AS createdAt FROM animation_review_comments WHERE board_id=? ORDER BY created_at,comment_id LIMIT 1000').bind(board).all();return json({board,comments:result.results,storage:'cloud'});}catch{return json({error:'云端留言暂不可读取'},503);}
}

export async function POST(request:Request){
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return json({error:'来源无效'},403);
 if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'格式无效'},415);
 try{const input=await request.json() as {board?:unknown;sceneId?:unknown;body?:unknown};if(!boardValid(input.board)||typeof input.sceneId!=='string'||!SCENES.has(input.sceneId)||typeof input.body!=='string'||!input.body.trim()||input.body.length>4000)return json({error:'留言内容无效'},400);await table();const id=crypto.randomUUID(),createdAt=new Date().toISOString(),body=input.body.trim();await env.DB.prepare('INSERT INTO animation_review_comments (board_id,comment_id,scene_id,body,created_at) VALUES (?,?,?,?,?)').bind(input.board,id,input.sceneId,body,createdAt).run();return json({saved:true,comment:{id,sceneId:input.sceneId,body,createdAt}});}catch{return json({error:'云端留言保存失败，请重试'},503);}
}

export async function DELETE(request:Request){
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return json({error:'来源无效'},403);
 try{const input=await request.json() as {board?:unknown;id?:unknown};if(!boardValid(input.board)||typeof input.id!=='string'||!/^[0-9a-f-]{36}$/i.test(input.id))return json({error:'留言编号无效'},400);await table();await env.DB.prepare('DELETE FROM animation_review_comments WHERE board_id=? AND comment_id=?').bind(input.board,input.id).run();return json({deleted:true,id:input.id});}catch{return json({error:'删除失败，请重试'},503);}
}
