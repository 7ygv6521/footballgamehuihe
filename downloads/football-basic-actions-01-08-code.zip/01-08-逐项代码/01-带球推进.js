// 原文件：public/animation-v4/legacy-actions.js，第 39—52 行。请结合 README 和完整源码使用。
function carryFrame(t){
  if(t<.30)return {actors:[actor(0)],ball:1.1,phase:-1};
  if(t<.48)return {actors:[actor(0,'start')],ball:1.1,phase:0};
  if(t<1.84){
    const q=clamp((t-.48)/1.36),person=ease(q);
    const touches=[0,.32,.64,1],index=q<.32?0:q<.64?1:2;
    const u=(q-touches[index])/(touches[index+1]-touches[index]);
    const ball=person+(1-person)*.12*4*u*(1-u);
    const contact=(q-touches[index])*1.36<.05;
    const pose=contact?'touch':(t-.48)%.28<.13?'runLow':'runHigh';
    return {actors:[actor(person*length,pose)],ball:ball*length+1.1,phase:contact?1:2};
  }
  return {actors:[actor(length,t<2.02?'collect':'stand')],ball:length+1.1,phase:3};
}
