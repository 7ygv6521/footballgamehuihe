// 原文件：public/animation-v4/legacy-actions.js，第 285—299 行。请结合 README 和完整源码使用。
function kickActor(t,contact,num='9',base=0,color=blue,y=0){
  let x=base-.55,pose='stand';
  if(t>=contact-.35&&t<contact-.025)pose='shotSet';
  else if(t>=contact-.025&&t<contact){x=lerp(base-.55,base,seg(t,contact-.025,contact));pose='shotSet'}
  else if(t>=contact){x=base+.52*ease(seg(t,contact+.08,contact+.32));pose=t<contact+.08?'shotContact':t<contact+.32?'shotFollow':t<contact+.52?'shotLand':t<contact+.70?'collect':'stand'}
  return man(x,pose,1,color,num,y);
}
function shootFrame(t){
  const contact=1.0,arrival=1.49;
  const a=kickActor(t,contact,'9');
  if(t<.28){a.x=-1.45;a.pose='stand'}
  else if(t<.65){a.x=lerp(-1.45,-.55,ease(seg(t,.28,.65)));a.pose=running(t)}
  const u=seg(t,contact,arrival);
  return {actors:[a],ball:t<contact?1.1:lerp(1.1,15.9,u),ballHeight:t>=contact&&t<arrival?Math.sin(u*Math.PI)*.8:0,phase:t<.28?-1:t<.65?0:t<contact?1:t<contact+.08?2:3,goal:true};
}
