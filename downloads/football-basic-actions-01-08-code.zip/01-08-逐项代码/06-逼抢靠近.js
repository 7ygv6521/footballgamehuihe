// 原文件：public/animation-v4/preview.js，第 46—65 行。请结合 README 和完整源码使用。
const compactContactIds=new Set([6,7,86,87,88,89,90,91,92,93]);
function compactContactScene(card,q){
 const {ctx}=card,id=card.id||card.baseId,kind=card.kind||'tackle';ctx.fillStyle='#235642';ctx.fillRect(0,0,640,330);
 const contact=.28,total=.60,buffer=contact+.045,time=q*total,double=[92,93].includes(id),slide=[86,87,88].includes(id),loose=id===87,retained=[6,88,89,90].includes(id),stay=id===89;
 const origins=[{x:1.55,y:0},{x:-7,y:0},{x:0,y:-7}],anchors=[origins[0],{x:-1.55,y:0},{x:0,y:-1.55}],ends=[retained&&!stay?{x:7,y:0}:origins[0],{x:-7,y:0},{x:0,y:-7}],winner=loose?-1:retained?0:id===93?2:1;
 const stroke=winner>=0&&!stay?buildDribbleMotion([anchors[winner],ends[winner]],buffer,total,{startBall:{x:0,y:0}}):null;
 let bp={x:0,y:0};
 for(let i=0;i<(double?3:2);i++){
  const incoming=time<contact,controlled=i===winner&&!incoming;
  const root=incoming?quickLoosePoint(origins[i],anchors[i],0,contact,time):controlled?(time<buffer||stay?anchors[i]:stroke.sample(time).root):quickLoosePoint(anchors[i],ends[i],contact,total,time);
  let pose=quickLoosePose(i!==0||time>=buffer&&!stay,controlled),action='second_ball_run';
  if(i===0&&[89,90,91].includes(id)&&incoming){const u=time/contact,wave=Math.sin(u*Math.PI*2)*Math.sin(u*Math.PI);pose={...pose,lean:8+wave*10,sway:wave*.20};}
  if(i===1&&slide&&time<contact+.11){const u=incoming?.45*time/contact:.45+.55*clamp((time-contact)/.11);action=kind;pose=sampleFootballPose(kind,u);if(kind!=='slide_miss')pose={...pose,contactPhase:u,contactPoint:{x:320,y:230}};}
  const from=incoming?origins[i]:anchors[i],to=incoming?anchors[i]:ends[i],v={x:to.x-from.x,y:to.y-from.y};
  body(ctx,{x:320+root.x*16,y:230+root.y*16},action,q,i===0?'#287cf1':'#e44a50',i===0?-1:1,String(i===0?9:i===1?4:6),{...pose,direction:Math.hypot(v.x,v.y)>.01?v:{x:i===0?-1:1,y:0}});
  if(controlled)bp=stay?{x:0,y:0}:stroke.sample(time).ball;
 }
 if(loose&&time>=contact)bp=quickLoosePoint({x:0,y:0},{x:0,y:5.5},contact,contact+.08,time);
 const v=mapGround({x:320+bp.x*16,y:230+bp.y*16});ball(ctx,v.x,v.y,v.y);card.label.textContent=time<contact?'快速上抢':loose?'触球即捅开':retained?'护住球 · 立即处理':'拿球 · 立即带走';
}
