// 原文件：public/animation-v4/legacy-actions.js，第 314—325 行。请结合 README 和完整源码使用。
function swayAt(q){
  const keys=[[0,0],[.2,.44],[.5,-1.18],[.76,.44],[1,0]];
  for(let i=1;i<keys.length;i++)if(q<=keys[i][0])return lerp(keys[i-1][1],keys[i][1],ease((q-keys[i-1][0])/(keys[i][0]-keys[i-1][0])));
  return 0;
}
function dodgeFrame(t){
  let ax=4.1,ay=0,dx=12.4,dy=-1.1,ap='stand',dp='stand',phase=-1;
  if(t>=.3&&t<.95){const q=ease(seg(t,.3,.95));ax=lerp(4.1,6,q);dx=lerp(12.4,8.5,q);ap=running(t);dp=running(t);phase=0}
  else if(t>=.95&&t<1.65){ax=6;dx=8.5;ay=swayAt(seg(t,.95,1.65));ap=t<1.14||t>=1.48?'feint':'turn';dp='defend';dy=lerp(-1.1,-1.45,ease(seg(t,1.18,1.5)));phase=1}
  else if(t>=1.65){const q=ease(seg(t,1.65,2.65));ax=lerp(6,13.5,q);ay=.46*Math.sin(q*Math.PI);dx=lerp(8.5,9.05,ease(seg(t,1.65,2.0)));dy=-1.45;ap=t<1.73?'touch':t<2.65?running(t):t<2.82?'collect':'stand';dp=t<2.14?'beaten':t<2.42?'brake':'stand';phase=t<2.05?2:3}
  return {actors:[man(ax,ap,1,blue,'10',ay),man(dx,dp,-1,red,'4',dy)],ball:ax+1.1,ballY:ay,phase};
}
