// 原文件：public/animation-v4/legacy-actions.js，第 63—75 行。请结合 README 和完整源码使用。
function passFrame(t){
  const receiver=14.5,contact=.90,arrival=1.70,cushionEnd=1.92;
  let pose='stand',x=0,phase=-1;
  if(t>=.35&&t<contact){pose='passSet';phase=0}
  else if(t>=contact&&t<1.01){pose='passContact';phase=1}
  else if(t>=1.01&&t<1.29){pose='passFollow';phase=2}
  else if(t>=1.29){pose=t<1.49?'collect':'stand';phase=3}
  if(t>=contact)x=.30*ease((t-contact)/.35);
  let ball=1.1,receiverPose=t<1.46?'stand':'receiveReady';
  if(t>=contact&&t<arrival)ball=lerp(1.1,receiver-1.45,(t-contact)/(arrival-contact));
  else if(t>=arrival){ball=lerp(receiver-1.45,receiver-.95,1-Math.pow(1-clamp((t-arrival)/(cushionEnd-arrival)),2));receiverPose=t<1.78?'receiveContact':t<cushionEnd?'cushion':t<2.1?'collect':'stand'}
  return {actors:[actor(x,pose),actor(receiver,receiverPose,-1,'8')],ball,phase};
}
