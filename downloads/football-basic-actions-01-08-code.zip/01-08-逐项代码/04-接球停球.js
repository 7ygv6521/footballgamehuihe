// 原文件：public/animation-v4/legacy-actions.js，第 76—94 行。请结合 README 和完整源码使用。
function receiveFrame(t){
  // Incoming ball from the left; retreat very slightly with contact, then turn out.
  const contact=1.08,cushionEnd=1.34,turnStart=1.63,driveStart=1.85,driveEnd=2.40;
  let x=10.1,pose='stand',dir=-1,phase=-1;
  if(t>=.28&&t<contact){x=lerp(10.1,9.6,ease((t-.28)/.50));pose=t<.68?'runLow':'receiveReady';phase=0}
  else if(t>=contact&&t<cushionEnd){x=lerp(9.6,9.74,ease((t-contact)/(cushionEnd-contact)));pose=t<1.16?'receiveContact':'cushion';phase=t<1.16?1:2}
  else if(t>=cushionEnd&&t<turnStart){x=9.74;pose='collect';phase=3}
  else if(t>=turnStart&&t<driveStart){x=9.74;pose='turn';dir=t<1.74?-1:1;phase=3}
  else if(t>=driveStart){const q=clamp((t-driveStart)/(driveEnd-driveStart));x=9.74+1.9*ease(q);dir=1;pose=t<driveEnd?(t<1.94?'touch':(t-driveStart)%.28<.13?'runLow':'runHigh'):t<2.57?'collect':'stand';phase=3}
  let ball=2.0;
  if(t>=.28&&t<contact)ball=lerp(2,8.15,(t-.28)/(contact-.28));
  else if(t>=contact&&t<cushionEnd)ball=lerp(8.15,8.79,1-Math.pow(1-clamp((t-contact)/(cushionEnd-contact)),2));
  else if(t>=cushionEnd&&t<turnStart)ball=8.79;
  else if(t>=turnStart&&t<driveStart)ball=8.79;
  else if(t>=driveStart){const q=clamp((t-driveStart)/(driveEnd-driveStart));ball=8.79+4.05*(1-Math.pow(1-q,2))}
  // On the turn-out, the ball travels around the player's near side, not through the body.
  const ballY=t>=driveStart&&t<driveEnd?Math.sin(clamp((t-driveStart)/(driveEnd-driveStart))*Math.PI)*.35:0;
  return {actors:[actor(x,pose,dir,'8')],ball,ballY,phase};
}
