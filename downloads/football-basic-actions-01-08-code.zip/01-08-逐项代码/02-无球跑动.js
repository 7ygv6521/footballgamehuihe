// 原文件：public/animation-v4/legacy-actions.js，第 53—62 行。请结合 README 和完整源码使用。
function runFrame(t){
  if(t<.30)return {actors:[actor(0)],phase:-1};
  if(t<.48)return {actors:[actor(0,'start')],phase:0};
  if(t<1.78){
    const q=clamp((t-.48)/1.3),x=ease(q)*length;
    const pose=q>.83?'brake':q<.2?((t-.48)%.24<.12?'runLow':'runHigh'):((t-.48)%.24<.12?'sprintLow':'sprintHigh');
    return {actors:[actor(x,pose)],phase:q>.83?3:q<.2?1:2};
  }
  return {actors:[actor(length,t<1.96?'collect':'stand')],phase:3};
}
